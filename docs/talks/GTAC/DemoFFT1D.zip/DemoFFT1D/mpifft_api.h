#ifndef __MPIFFT_API_H__
#define __MPIFFT_API_H__

#include <mpi.h>
#include <rocfft.h>
#include "FFT1D.h"
#include "util.h"
#include <hpcc.h>
#include <../FFT/hpccfft.h>
#include <../FFT/wrapmpifftw.h>

#ifndef ROCM_CHECK
#define ROCM_CHECK(stmt)                                                \
do {                                                                    \
   hipError_t rocm_errno = (stmt);                                           \
   if (0 != rocm_errno) {                                                    \
       fprintf(stderr, "[%s:%d] ROCM call '%s' failed with %d: %s \n",  \
        __FILE__, __LINE__, #stmt, rocm_errno, hipGetErrorString(rocm_errno));    \
       exit(EXIT_FAILURE);                                              \
   }                                                                    \
   assert(hipSuccess == rocm_errno);                                         \
} while (0)
#endif

typedef double Complex[2];
// typedef long long s64Int_t;
// typedef unsigned long long u64Int_t;

#ifdef __cplusplus
extern "C" {
#endif
extern double                           HPL_dlamch
STDC_ARGS( (
   const HPL_T_MACH
) );

extern int HPCC_bcnrand(u64Int_t n, u64Int_t a, void *x);
void fft_mpi_create_plan(struct FFTPlan1D *plan, MPI_Comm comm, int _length, int type, int *src_dev); 
void fft_mpi(struct FFTPlan1D *plan, Complex *in, Complex *out, Complex *total_data, MPI_Comm comm, int in_len);
void fft_mpi_destroy_plan(struct FFTPlan1D *plan, int src_dev, int rank);

void rocfft_mpi_create_plan(rocfft_plan *plan, MPI_Comm comm, int _length, int type, int *src_dev); 
void rocfft_mpi(rocfft_plan *plan, Complex *in, Complex *out, Complex *total_data, MPI_Comm comm, int in_len);
void rocfft_mpi_destroy_plan(rocfft_plan *plan, int src_dev, int rank);

void MPIFFT_NEW(HPCC_Params *params, int doIO, FILE *outFile, MPI_Comm comm, int locN, double *UGflops, s64Int_t *Un, double *UmaxErr, int *Ufailure);
void ROCFFT_MPI_NEW(HPCC_Params *params, int doIO, FILE *outFile, MPI_Comm comm, int locN, double *UGflops, s64Int_t *Un, double *UmaxErr, int *Ufailure);

#ifdef __cplusplus
}
#endif


#endif // __MPIFFT_API_H__