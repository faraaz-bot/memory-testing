#define  __HIP_PLATFORM_HCC__

#include <iostream>
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <math.h>
#include <time.h>
#include "hip/hip_runtime.h"

#include "FFT1D.h"

#include "util.h"




using namespace std;



int main(int argc, char *argv[]) {

    size_t X = atoi(argv[1]);
    
    int Ntrial = atoi(argv[2]);
    int printResult = atoi(argv[3]);



    const unsigned int N = X;
   
    int deviceCount, deviceId;
    hipDeviceProp_t prop;

    //Get device number and properties
    ErrChk(hipGetDeviceCount(&deviceCount));
    printf("Number of devices: %d\n", deviceCount);

    //Choose the device
    ErrChk(hipSetDevice(2));
    ErrChk(hipGetDevice(&deviceId));
    printf("Current deviceId: %d\n", deviceId);

    printf("Input size: %zu\n", X);



    /* FFT Starts */
    //Host input array

    double *data, *outData;
    size_t bytes = 2 * N * sizeof(double);

    //Allocate memory for the array on host
    data = (double *) malloc(bytes);
    outData = (double *) malloc(bytes);




    for (unsigned int i = 0; i < N; i++) {
        data[2 * i] = i + 1.0;//sin(2*PI*i/N);
        data[2 * i + 1] = 0.0;
        //printf("before FFT: %lf:%lf\n",data[2*i], data[2*i+1]);
    }


    struct FFTPlan1D plan;
    hipEvent_t start, stop;
    float elapsedTime = 0.f;

    hipEventCreate(&start);
    hipEventCreate(&stop);
    hipEventRecord(start, NULL);


    FFTPlan1DInit(&plan, X, data, FORWARD);
    hipEventRecord(stop, NULL);
    hipEventSynchronize(stop);
    hipEventElapsedTime(&elapsedTime, start, stop);
    printf("Tuning time: %.8f ms\n", elapsedTime);

   


    FFTPlan1DExec(&plan);

    //Performance test
    #if 1
    hipEventRecord(start, NULL);
    for (int itrial = 0; itrial < Ntrial; itrial++) {
        FFTPlan1DExec(&plan);
    }
    hipEventRecord(stop, NULL);
    hipEventSynchronize(stop);
    hipEventElapsedTime(&elapsedTime, start, stop);

    printf("Average hip time: %.10f ms\n", elapsedTime / Ntrial);
    double opscount = (double)5 * X * log(X) / log(2.0);
    printf("Average Execution gflops:  %.10f\n", opscount/(1e6 * elapsedTime / Ntrial));
    #endif


 


    //ouput data
    ErrChk(hipMemcpy(outData, plan.outBuffer, plan.bufferSize, hipMemcpyDeviceToHost));

    FFTPlan1DDestroy(&plan);


    #if 1

    hipEventRecord(start, NULL);

    FFTPlan1DInit(&plan, X, outData, INVERSE);
    FFTPlan1DExec(&plan);

    hipEventRecord(start, NULL);
    for (int itrial = 0; itrial < Ntrial; itrial++) {
        FFTPlan1DExec(&plan);
    }
    hipEventRecord(stop, NULL);

    double* outInverseData = (double *) malloc(bytes);
    ErrChk(hipMemcpy(outInverseData, plan.outBuffer, plan.bufferSize, hipMemcpyDeviceToHost));
    
    double* iData = (double *) malloc(bytes);
    iData[0] = outInverseData[0] / N;
    iData[1] = outInverseData[1] / N;
    for(int i = 1; i < N; i++){
        iData[2 * i] = outInverseData[2 * (N - i)]/N;
        iData[2 * i + 1] = outInverseData[2 * (N - i) + 1]/N;

    }
    hipEventSynchronize(stop);
    hipEventElapsedTime(&elapsedTime, start, stop);
    printf("Average Inverse time: %.8f ms\n", elapsedTime);

    double tmp1, tmp2, tmp3, maxErr = 0.0;
    for (int i = 0; i < N; i++) {
        tmp1 = data[2*i]-iData[2*i];
        tmp2 = data[2*i+1]-iData[2*i+1];
        tmp3 = sqrt( tmp1*tmp1 + tmp2*tmp2 );
        maxErr = maxErr >= tmp3 ? maxErr : tmp3;
    }
    printf("Max error: %.8f\n", maxErr);


    if (printResult == 1) {
        for (int i = 0; i < 8; i++) {
            cout << "element " << i << " input:  (" << data[2 * i] << "," << data[2 * i + 1] << ")"
                 << " output: (" << iData[2 * i] << "," << iData[2 * i + 1] << ")" << endl;
        }
        for (int i = N - 8; i < N; i++) {
            cout << "element " << i << " input:  (" << data[2 * i] << "," << data[2 * i + 1] << ")"
                 << " output: (" << iData[2 * i] << "," << iData[2 * i + 1] << ")" << endl;
        }
    }

    #endif

    if (printResult == 1) {
        for (int i = 0; i < 8; i++) {
            cout << "element " << i << " input:  (" << data[2 * i] << "," << data[2 * i + 1] << ")"
                 << " output: (" << outData[2 * i] << "," << outData[2 * i + 1] << ")" << endl;
        }
        for (int i = N - 8; i < N; i++) {
            cout << "element " << i << " input:  (" << data[2 * i] << "," << data[2 * i + 1] << ")"
                 << " output: (" << outData[2 * i] << "," << outData[2 * i + 1] << ")" << endl;
        }
    }

    FFTPlan1DDestroy(&plan);
    free(outData);
    free(data);


    return 0;
}

