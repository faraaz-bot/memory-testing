// #include <hip/hip_runtime.h>
#define ErrChk(code) { Assert((code), __FILE__, __LINE__); }

static inline void Assert(hipError_t code, const char *file, int line) {
    if (code != hipSuccess) {
        printf("HIP Runtime Error: %s:%d:'%s'\n", file, line, hipGetErrorString(code));
        exit(EXIT_FAILURE);
    }
}


#define KernelErrChk(){\
        hipError_t errSync  = hipGetLastError();\
        hipError_t errAsync = hipDeviceSynchronize();\
        if (errSync != hipSuccess) {\
              printf("Sync kernel error: %s\n", hipGetErrorString(errSync));\
              exit(EXIT_FAILURE);\
        }\
        if (errAsync != hipSuccess){\
            printf("Async kernel error: %s\n", hipGetErrorString(errAsync));\
            exit(EXIT_FAILURE);\
        }\
}
