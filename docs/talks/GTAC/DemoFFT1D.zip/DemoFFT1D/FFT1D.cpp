#include "FFT1D.h"
#include "kernelRadix2/kernelRadix2.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <vector>
#include <map>
#include <iostream>
#include "util.h"
using namespace std;

    
const int row = 10, col = 15;

uint64_t *getStageRadix(size_t size0){
    int radixAvailable = 6;
    uint64_t radices[6] = {8, 7, 5, 4, 3, 2};
    uint64_t *stageRadix;
    stageRadix = (uint64_t *)malloc(sizeof(uint64_t)*21);

    for (int i = 0; i < 21; i++) {
        stageRadix[i] = 0;
    }
    int numStages = 0;
    for (int index = 0; index < 6; index++) {
        while (size0 >= radices[index]){
            if (size0 % radices[index] == 0){
                size0 = size0 / radices[index];
                stageRadix[numStages] = radices[index];
                numStages++;
            }
            else break;
            if (size0 == 1) break;
        }
    }
   
    stageRadix[20] = numStages;
    return stageRadix;
}


double2 *initializeLUT(size_t size0, uint64_t *stageRadix, size_t nx) {
    double double_PI = 3.1415926535897932384626433832795;
    uint64_t numStages = stageRadix[20];
    uint64_t dimMult = 1;
	uint64_t maxStageSum = 0;

    uint64_t localStageSize = 1;
	uint64_t localStageSum = 0;
    uint64_t stageStartSize = 1, fftDim = 1;
    for (uint64_t i = 0; i < numStages; i++) {
        switch (stageRadix[i])
        {
        case 2:
            maxStageSum += dimMult;
            break;
        case 3:
            maxStageSum += dimMult * 2;
        case 4:
			maxStageSum += dimMult * 2;
			break;
		case 5:
			maxStageSum += dimMult * 4;
			break;
		case 7:
			maxStageSum += dimMult * 6;
			break;
		case 8:
			maxStageSum += dimMult * 3;
			break;
        default:
            break;
        }
        dimMult *= stageRadix[i]; 
    }
 
    size_t bufferLUTSize = (maxStageSum) * 2 * sizeof(double);
    if(nx >= 8192){
        if(nx / 64 >= 128 && nx / 64 <= 512) fftDim = 64;
        else if (nx / 512 >= 64 && nx / 512 <= 512 ) stageStartSize = 512;
        else if (nx / 512 <= 2048) fftDim = 512;
        else stageStartSize = 2048;

        if (stageStartSize == 1) stageStartSize = nx/fftDim;
        if (fftDim == 1) fftDim = nx/stageStartSize;
        bufferLUTSize = (maxStageSum + stageStartSize * fftDim) * 2 * sizeof(double);
    }

    // std::cout<<"bufferLUTSize = "<<bufferLUTSize<<std::endl;

    double *tempLUT = (double *) malloc(bufferLUTSize);

    for (uint64_t i = 0; i < numStages; i++){
        if((stageRadix[i] & (stageRadix[i]-1)) == 0){
            for (uint64_t k = 0; k < log2(stageRadix[i]); k++) {
						for (uint64_t j = 0; j < localStageSize; j++) {
							tempLUT[2 * (j + localStageSum)] = cos(j * double_PI / localStageSize / pow(2, k));
							tempLUT[2 * (j + localStageSum) + 1] = sin(j * double_PI / localStageSize / pow(2, k));
						}
						localStageSum += localStageSize;
					}
					localStageSize *= stageRadix[i];
        }
        else {
            for (uint64_t k = (stageRadix[i]-1); k > 0; k--) {
                for (uint64_t j = 0; j < localStageSize; j++) {
                    tempLUT[2 * (j + localStageSum)] = cos(j * 2.0 * k / stageRadix[i] * double_PI / localStageSize);
                    tempLUT[2 * (j + localStageSum) + 1] = sin(j * 2.0 * k / stageRadix[i] * double_PI / localStageSize);
                    }
                    localStageSum += localStageSize;
                    }
                    localStageSize *= stageRadix[i];
        }
    }

    if (nx >= 8192) {
        // std::cout<<"stageStarSize = "<<stageStartSize<<std::endl;
		// std::cout<<"fftdim = "<<fftDim<<std::endl;
		for (uint64_t i = 0; i < stageStartSize; i++) {
			for (uint64_t j = 0; j < fftDim; j++) {
				double angle = 2 * double_PI * ((i * j) / (double)(stageStartSize * fftDim));
				tempLUT[maxStageSum * 2 + 2 * (i + j * stageStartSize)] = cos(angle);
				tempLUT[maxStageSum * 2 + 2 * (i + j * stageStartSize) + 1] = sin(angle);
				}
			}
		}
    	// std::cout<<"bufferLUT:\n";
		// for(int i =0 ; i< 1000;i++){
		// 	std::cout<< tempLUT[i]<<"   ";
		// }
		// std::cout<<"\n";
    double2 *bufferLUT = nullptr;
    ErrChk(hipMalloc((void **) &bufferLUT, bufferLUTSize));

    ErrChk(hipMemcpy(bufferLUT, tempLUT, bufferLUTSize, hipMemcpyHostToDevice));

    free(tempLUT);
    tempLUT = nullptr;
    return bufferLUT;

}
void FFTPlan1DInit(FFTPlan1D *plan, size_t nx, double *data, int type){
    plan->Nx = nx;
    plan->inputLength = nx;
    plan->bufferSize = sizeof(double) * plan->inputLength * 2;

    if(nx <= 4096){
        plan->stageRadixX = getStageRadix(plan->Nx);    
        plan->bufferLUTX = initializeLUT(plan->Nx, plan->stageRadixX, plan->Nx);
    }else if(nx >= 8192 && nx < 8388608){
        int tmpX = 0, tmpY = 0;
        if(nx / 64 >= 128 && nx / 64 <= 512) tmpY = 64;
        else if (nx / 512 >= 64 && nx / 512 <= 512 ) tmpX = 512;
        else if (nx / 512 <= 2048) tmpY = 512;
        else tmpX = 2048;

        if (tmpX == 0) tmpX = nx/tmpY;
        if (tmpY == 0) tmpY = nx/tmpX;

        plan->stageRadixX = getStageRadix(tmpX);
        plan->stageRadixY = getStageRadix(tmpY);
        // plan->stageRadixZ = getStageRadix(plan->Nx);

        
        plan->bufferLUTX = initializeLUT(tmpY, plan->stageRadixY, plan->Nx);
        plan->bufferLUTY = initializeLUT(tmpX, plan->stageRadixX, tmpX);

        // plan->bufferLUTY = initializeLUT(tmpY, plan->stageRadixY);
        // plan->bufferLUTZ = initializeLUT(plan->Nx, plan->stageRadixZ);
    }

    

    
    ErrChk(hipMalloc(&plan->inBuffer, plan->bufferSize));
    ErrChk(hipMalloc(&plan->outBuffer, plan->bufferSize));
    ErrChk(hipMalloc(&plan->tmpInBuffer, plan->bufferSize));
    ErrChk(hipMalloc(&plan->tmpOutBuffer, plan->bufferSize));

    //ErrChk(hipMalloc((void **) &plan->tmpBuffer, plan->bufferSize));
    if (data != NULL)
        ErrChk(hipMemcpy(plan->inBuffer, data, plan->bufferSize, hipMemcpyHostToDevice));



    int kernelNum = 1;
    if(plan->Nx > 4096 && plan->Nx < 8388608) kernelNum =2;
    if(plan->Nx >= 8388608) kernelNum = 3;
    plan->gridSize = (dim3 *)malloc(sizeof(dim3) * kernelNum);
    plan->blockSize = (dim3 *)malloc(sizeof(dim3) * kernelNum);
    plan->shareMem = (uint64_t *)malloc(sizeof(uint64_t)*kernelNum);

    if(kernelNum == 1){
        plan->gridSize[0].x = 1;
        plan->gridSize[0].y = 1;
        plan->gridSize[0].z = 1;
        plan->blockSize[0].x = (uint64_t)ceil(nx / 8.0);
        plan->blockSize[0].y = 1;
        plan->blockSize[0].z = 1;
        uint64_t sharedStrideBankConflictFirstStages = ((nx >  32/2) && ((nx & (nx - 1)) == 0)) ? nx / 1 * (32 / 2 + 1) / (32 / 2) : nx;
        uint64_t sharedStrideReadWriteConflict = ((32 / 2 <= 1)) ? nx / 1 + 1 : 16 / 1 + (32 / 2) / 1;
        uint64_t maxSharedStride = (sharedStrideBankConflictFirstStages < sharedStrideReadWriteConflict) ? sharedStrideReadWriteConflict : sharedStrideBankConflictFirstStages;
        plan->shareMem[0] = 16 * maxSharedStride > 65536 ? 65536 : 16 * maxSharedStride;
    }
    else{
        vector <vector<int>> config(row, vector<int>(col, 0));
        FILE *fp;
        fp = fopen("config.txt", "r");
        for (int j = 0; j < row; j++) {
            for (int i = 0; i < col - 1; i++) {
                fscanf(fp, "%d,", &config[j][i]);
            }
            fscanf(fp, "%d", &config[j][col - 1]);
            }
            fclose(fp);
    
        for (int j = 0; j < row; j++) {
             if (config[j][0] == nx) {
                 plan->gridSize[0].x = config[j][1];
                 plan->gridSize[0].y = config[j][2];
                 plan->gridSize[0].z = config[j][3];
                 plan->blockSize[0].x = config[j][4];
                 plan->blockSize[0].y = config[j][5];
                 plan->blockSize[0].z = config[j][6];
                 plan->shareMem[0] = config[j][14];
                 plan->gridSize[1].x = config[j][8];
                 plan->gridSize[1].y = config[j][9];
                 plan->gridSize[1].z = config[j][10];
                 plan->blockSize[1].x = config[j][11];
                 plan->blockSize[1].y = config[j][12];
                 plan->blockSize[1].z = config[j][13];
                 plan->shareMem[1] = config[j][7];
                 
                //  if(plan->Nx >= 8388608 ){
                //      plan->gridSize[2].x = config[j][16];
                //      plan->gridSize[2].y = config[j][17];
                //      plan->gridSize[2].z = config[j][18];
                //      plan->blockSize[2].x = config[j][19];
                //      plan->blockSize[2].y = config[j][20];
                //      plan->blockSize[2].z = config[j][21];
                //      plan->shareMem[2] = config[j][22];
                //     }
               }
        }
    }

//     cout<<plan->shareMem[0]<<endl;
  
//     cout << plan->gridSize[0].x <<"  "<< plan->gridSize[0].y <<"  "<< plan->gridSize[0].z <<"  "<<plan->blockSize[0].x<<"  "<<plan->blockSize[0].y<<"  "<<plan->blockSize[0].z<< endl;
   
//    cout<<plan->shareMem[1]<<endl;
  
//     cout << plan->gridSize[1].x <<"  "<< plan->gridSize[1].y <<"  "<< plan->gridSize[1].z <<"  "<<plan->blockSize[1].x<<"  "<<plan->blockSize[1].y<<"  "<<plan->blockSize[1].z<< endl;
    // plan->gridSize[1].x = (uint64_t)ceil(nx * ny / 2048.0);
    // if (ny > 256)
    // {
    //     plan->gridSize[1].x = (uint64_t)ceil(nx * ny / 4096.0);
    // }
    // plan->gridSize[1].y = 1;
    // plan->gridSize[1].z = nz;

   
    string kernel_name = "";


    typedef void (*pFunc1)(double2 *, double2 *, double2 *);
    map <string, pFunc1> strFuncMap1;
    {
        strFuncMap1["2"] = &kernel_2;
        strFuncMap1["4"] = &kernel_4;
        strFuncMap1["8"] = &kernel_8;
        strFuncMap1["16"] = &kernel_16;
        strFuncMap1["32"] = &kernel_32;
        strFuncMap1["64"] = &kernel_64;
        strFuncMap1["128"] = &kernel_128;
        strFuncMap1["256"] = &kernel_256;
        strFuncMap1["512"] = &kernel_512;
        strFuncMap1["1024"] = &kernel_1024;
        strFuncMap1["2048"] = &kernel_2048;
        strFuncMap1["4096"] = &kernel_4096;

        strFuncMap1["2_b"] = &kernel_2_b;
        strFuncMap1["4_b"] = &kernel_4_b;
        strFuncMap1["8_b"] = &kernel_8_b;
        strFuncMap1["16_b"] = &kernel_16_b;
        strFuncMap1["32_b"] = &kernel_32_b;
        strFuncMap1["64_b"] = &kernel_64_b;
        strFuncMap1["128_b"] = &kernel_128_b;
        strFuncMap1["256_b"] = &kernel_256_b;
        strFuncMap1["512_b"] = &kernel_512_b;
        strFuncMap1["1024_b"] = &kernel_1024_b;
        strFuncMap1["2048_b"] = &kernel_2048_b;
        strFuncMap1["4096_b"] = &kernel_4096_b;

        strFuncMap1["8192"] = &kernel_8192_1;
        strFuncMap1["16384"] = &kernel_16384_1;
        strFuncMap1["32768"] = &kernel_32768_1;
        strFuncMap1["65536"] = &kernel_65536_1;
        strFuncMap1["131072"] = &kernel_131072_1;
        strFuncMap1["262144"] = &kernel_262144_1;
        strFuncMap1["524288"] = &kernel_524288_1;
        strFuncMap1["1048576"] = &kernel_1048576_1;
        strFuncMap1["2097152"] = &kernel_2097152_1;
        strFuncMap1["4194304"] = &kernel_4194304_1;

        strFuncMap1["8192_b"] = &kernel_8192_b_1;
        strFuncMap1["16384_b"] = &kernel_16384_b_1;
        strFuncMap1["32768_b"] = &kernel_32768_b_1;
        strFuncMap1["65536_b"] = &kernel_65536_b_1;
        strFuncMap1["131072_b"] = &kernel_131072_b_1;
        strFuncMap1["262144_b"] = &kernel_262144_b_1;
        strFuncMap1["524288_b"] = &kernel_524288_b_1;
        strFuncMap1["1048576_b"] = &kernel_1048576_b_1;
        strFuncMap1["2097152_b"] = &kernel_2097152_b_1;
        strFuncMap1["4194304_b"] = &kernel_4194304_b_1;

    }

    typedef void (*pFunc2)(double2 *, double2 *, double2 *);
    map <string, pFunc2> strFuncMap2;
    {
        strFuncMap2["8192"] = &kernel_8192_2;
        strFuncMap2["16384"] = &kernel_16384_2;
        strFuncMap2["32768"] = &kernel_32768_2;
        strFuncMap2["65536"] = &kernel_65536_2;
        strFuncMap2["131072"] = &kernel_131072_2;
        strFuncMap2["262144"] = &kernel_262144_2;
        strFuncMap2["524288"] = &kernel_524288_2;
        strFuncMap2["1048576"] = &kernel_1048576_2;
        strFuncMap2["2097152"] = &kernel_2097152_2;
        strFuncMap2["4194304"] = &kernel_4194304_2;
        strFuncMap2["8192_b"] = &kernel_8192_b_2;

        strFuncMap2["16384_b"] = &kernel_16384_b_2;
        strFuncMap2["32768_b"] = &kernel_32768_b_2;
        strFuncMap2["65536_b"] = &kernel_65536_b_2;
        strFuncMap2["131072_b"] = &kernel_131072_b_2;
        strFuncMap2["262144_b"] = &kernel_262144_b_2;
        strFuncMap2["524288_b"] = &kernel_524288_b_2;
        strFuncMap2["1048576_b"] = &kernel_1048576_b_2;
        strFuncMap2["2097152_b"] = &kernel_2097152_b_2;
        strFuncMap2["4194304_b"] = &kernel_4194304_b_2;

    }

    kernel_name = to_string(nx);
    if(type == INVERSE) kernel_name += "_b";
    if(plan->Nx <= 4096){
        plan->kernelFunc[0] = strFuncMap1[kernel_name];
    }else if(plan->Nx > 4096 && plan->Nx < 8388608){
        plan->kernelFunc[0] = strFuncMap1[kernel_name];
        plan->kernelFunc[1] = strFuncMap2[kernel_name];
    }
    
}

void FFTPlan1DExec(FFTPlan1D *plan){

    if(plan->Nx <= 4096){
         hipLaunchKernelGGL(plan->kernelFunc[0], plan->gridSize[0], plan->blockSize[0], plan->shareMem[0], 0, plan->inBuffer, plan->outBuffer, plan->bufferLUTX);
    }else if(plan->Nx > 4096 && plan->Nx < 8388608)
    {
        hipLaunchKernelGGL(plan->kernelFunc[0], plan->gridSize[0], plan->blockSize[0], plan->shareMem[0], 0, plan->inBuffer, plan->tmpOutBuffer,plan->bufferLUTX);
        plan->tmpInBuffer = plan->tmpOutBuffer;
        hipLaunchKernelGGL(plan->kernelFunc[1], plan->gridSize[1], plan->blockSize[1], plan->shareMem[1], 0, plan->tmpInBuffer, plan->outBuffer,plan->bufferLUTY);
    
    }
    
}

void FFTPlan1DDestroy(FFTPlan1D *plan){
    ErrChk(hipFree(plan->inBuffer));
    ErrChk(hipFree(plan->outBuffer));
    ErrChk(hipFree(plan->bufferLUTX));
    // ErrChk(hipFree(plan->bufferLUTY));
    // ErrChk(hipFree(plan->bufferLUTZ));
    ErrChk(hipFree(plan->tmpOutBuffer));

    free(plan->gridSize);
    free(plan->blockSize);
    free(plan->shareMem);

}
