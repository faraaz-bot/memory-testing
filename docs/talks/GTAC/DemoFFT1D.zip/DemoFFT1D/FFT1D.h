#define __HIP_PLATFORM_HCC__
#ifndef __FFT1D_H__
#define __FFT1D_H__
#include "hip/hip_runtime.h"
#include <hip/hip_vector_types.h>



#define FORWARD 1
#define INVERSE 0





struct FFTPlan1D
{
	size_t Nx;

    unsigned int inputLength;
    size_t bufferSize;

    uint64_t *stageRadixX;
    uint64_t *stageRadixY;
    uint64_t *stageRadixZ;
	

	double2 *bufferLUTX;			// twiddles
    double2 *bufferLUTY;
    double2 *bufferLUTZ;
    double2 *inBuffer;
    double2 *outBuffer;
    
    double2 *tmpInBuffer;
    double2 *tmpOutBuffer;

    void (*kernelFunc[3])(double2 *, double2 *, double2 *);
    


	dim3 *gridSize;			// Number of thread blocks in grid
	dim3 *blockSize;          // Number of threads in each thread block
    //dim3 gridSize2;
    //dim3 blockSize2;
    uint64_t *shareMem;
};

#ifdef __cplusplus
extern "C" {
#endif
uint64_t *getStageRadix(size_t size0);
#ifdef __cplusplus
}
#endif



#ifdef __cplusplus
extern "C" {
#endif
void FFTPlan1DInit(struct FFTPlan1D *plan, size_t nx, double *data, int type);
#ifdef __cplusplus
}
#endif

#ifdef __cplusplus
extern "C" {
#endif
double2 *initializeLUT(size_t size0, uint64_t *stageRadix);
#ifdef __cplusplus
}
#endif

#ifdef __cplusplus
extern "C" {
#endif
void FFTPlan1DExec(struct FFTPlan1D *plan);
#ifdef __cplusplus
}
#endif

#ifdef __cplusplus
extern "C" {
#endif
void FFTPlan1DDestroy(struct FFTPlan1D *plan);
#ifdef __cplusplus
}
#endif

#endif
