# hipcc -O3 -I /opt/rocm/include -L /opt/rocm/lib FFT1D.cpp -fPIC -shared -o libtest.so
# hipcc -O3 -I /opt/rocm/include -L /opt/rocm/lib test_1D.cpp -L. -ltest -o test_1D
# hipcc -O3 -I /opt/rocm/include -L /opt/rocm/lib FFT1D.cpp -g test_1D.cpp -o test_1D -lamdhip64
hipcc -g rocFFT_1d.cpp -O3 -I /opt/rocm/hip/include -I /opt/rocm/rocfft/include -L /opt/rocm/hip/lib -L /opt/rocm/rocfft/lib -lrocfft -o rocFFT_1d
