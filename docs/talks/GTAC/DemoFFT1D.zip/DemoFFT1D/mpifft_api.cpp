#include "mpifft_api.h"

void fft_mpi_create_plan(FFTPlan1D *plan, MPI_Comm comm, int _length, int type, int *src_dev) 
{
    int mpi_rank, mpi_size;
    MPI_Comm_rank(MPI_COMM_WORLD, &mpi_rank);
    MPI_Comm_size(MPI_COMM_WORLD, &mpi_size);

    hipGetDevice(src_dev);

    int device_count;
    hipGetDeviceCount(&device_count);
    hipSetDevice(mpi_rank % device_count);

    if (mpi_rank == 0) {
        const unsigned int length = _length;
        FFTPlan1DInit(plan, length, NULL, type);
    }
}

void fft_mpi(FFTPlan1D *plan, Complex *in, Complex *out, Complex *total_data, MPI_Comm comm, int in_len) 
{
    int mpi_rank, mpi_size, len = in_len;
    MPI_Comm_rank(comm, &mpi_rank);
    MPI_Comm_size(comm, &mpi_size);

    // params for MPI_Gatherv() and MPI_Scatter()
    int all_len[mpi_size], displs[mpi_size], tmp = ceil((double)len / mpi_size);
    for (int i = 0; i < mpi_size; ++i) {
        if (i != mpi_size - 1) {
            all_len[i] = tmp * 2;
        }
        else {
            all_len[i] = (len - (mpi_size - 1) * tmp) * 2;
        }
        displs[i] = i * tmp * 2;
    }

    if (mpi_rank == 0) {

        MPI_Request req;

        // Isend/Irecv
        MPI_Request reqs[mpi_size - 1];
        for (int i = 0, count = 0; i < mpi_size; ++i) {
            if (i != mpi_rank) {
                MPI_Irecv(total_data + i * tmp, all_len[i], MPI_DOUBLE, i, 0, comm, &reqs[count++]);
            }
            else {
                hipMemcpy(total_data, in, tmp * sizeof(Complex), hipMemcpyDeviceToDevice);
            }
        }
        MPI_Waitall(mpi_size - 1, reqs, MPI_STATUSES_IGNORE);
        printf("rank %d: success to receive data!\n", mpi_rank);

        plan->inBuffer = (double2*)total_data;

        FFTPlan1DExec(plan);
        hipDeviceSynchronize();

        MPI_Iscatterv(plan->outBuffer, all_len, displs, MPI_DOUBLE, out, all_len[0], MPI_DOUBLE, 0, comm, &req);
        MPI_Wait(&req, MPI_STATUS_IGNORE);
    }
    else {
        MPI_Request req;
        // MPI_CHECK(MPI_Igatherv(data_gpu, data_count * 2, MPI_DOUBLE, NULL, NULL, NULL, MPI_DOUBLE, 0, MPI_COMM_WORLD, &req));
        // MPI_CHECK(MPI_Wait(&req, MPI_STATUS_IGNORE));

        MPI_Isend(in, all_len[mpi_rank], MPI_DOUBLE, 0, 0, comm, &req);
        MPI_Wait(&req, MPI_STATUS_IGNORE);
        printf("rank %d: success to send data!\n", mpi_rank);
        // MPI_CHECK(MPI_Send(data_gpu, data_count * 2, MPI_DOUBLE, 0, 0, MPI_COMM_WORLD));
        
        MPI_Iscatterv(NULL, NULL, NULL, MPI_DOUBLE, out, all_len[mpi_rank], MPI_DOUBLE, 0, comm, &req);
        MPI_Wait(&req, MPI_STATUS_IGNORE);

    }
}

void fft_mpi_destroy_plan(FFTPlan1D *plan, int src_dev, int rank) 
{
    if (rank == 0)
        FFTPlan1DDestroy(plan);
    ROCM_CHECK(hipSetDevice(src_dev));
}

void rocfft_mpi_create_plan(rocfft_plan *plan, MPI_Comm comm, int _length, rocfft_transform_type type, int *src_dev)
{
    int mpi_rank, mpi_size;
    MPI_Comm_rank(MPI_COMM_WORLD, &mpi_rank);
    MPI_Comm_size(MPI_COMM_WORLD, &mpi_size);

    hipGetDevice(src_dev);

    int device_count;
    hipGetDeviceCount(&device_count);
    hipSetDevice(mpi_rank % device_count);

    if (mpi_rank == 0) {
        const size_t length = _length;
        rocfft_plan_create(plan, rocfft_placement_inplace, type, rocfft_precision_double, 1, &length, 1, NULL);
    }
}

void rocfft_mpi(rocfft_plan *plan, Complex *in, Complex *out, Complex *total_data, MPI_Comm comm, int in_len)
{
    int mpi_rank, mpi_size, len = in_len;
    MPI_Comm_rank(comm, &mpi_rank);
    MPI_Comm_size(comm, &mpi_size);

    // params for MPI_Gatherv() and MPI_Scatter()
    int all_len[mpi_size], displs[mpi_size], tmp = ceil((double)len / mpi_size);
    for (int i = 0; i < mpi_size; ++i) {
        if (i != mpi_size - 1) {
            all_len[i] = tmp * 2;
        }
        else {
            all_len[i] = (len - (mpi_size - 1) * tmp) * 2;
        }
        displs[i] = i * tmp * 2;
    }

    if (mpi_rank == 0) {

        MPI_Request req;

        // Isend/Irecv
        MPI_Request reqs[mpi_size - 1];
        for (int i = 0, count = 0; i < mpi_size; ++i) {
            if (i != mpi_rank) {
                MPI_Irecv(total_data + i * tmp, all_len[i], MPI_DOUBLE, i, 0, comm, &reqs[count++]);
            }
            else {
                hipMemcpy(total_data, in, tmp * sizeof(Complex), hipMemcpyDeviceToDevice);
            }
        }
        MPI_Waitall(mpi_size - 1, reqs, MPI_STATUSES_IGNORE);

        // Check if the plan requires a work buffer
        size_t work_buf_size = 0;
        rocfft_plan_get_work_buffer_size(*plan, &work_buf_size);
        void *work_buf = nullptr;
        rocfft_execution_info info = nullptr;
        if (work_buf_size)
        {
            rocfft_execution_info_create(&info);
            hipMalloc(&work_buf, work_buf_size);
            rocfft_execution_info_set_work_buffer(info, work_buf, work_buf_size);
        }

        rocfft_execute(*plan, (void**)&total_data, NULL, info);
        hipDeviceSynchronize();

        MPI_Iscatterv(total_data, all_len, displs, MPI_DOUBLE, out, all_len[0], MPI_DOUBLE, 0, comm, &req);
        MPI_Wait(&req, MPI_STATUS_IGNORE);

        // Clean up work buffer
        if (work_buf_size)
        {
            hipFree(work_buf);
            rocfft_execution_info_destroy(info);
        }
    }
    else {
        MPI_Request req;
        // MPI_CHECK(MPI_Igatherv(data_gpu, data_count * 2, MPI_DOUBLE, NULL, NULL, NULL, MPI_DOUBLE, 0, MPI_COMM_WORLD, &req));
        // MPI_CHECK(MPI_Wait(&req, MPI_STATUS_IGNORE));

        MPI_Isend(in, all_len[mpi_rank], MPI_DOUBLE, 0, 0, comm, &req);
        MPI_Wait(&req, MPI_STATUS_IGNORE);
        printf("rank %d: success to send data!\n", mpi_rank);
        // MPI_CHECK(MPI_Send(data_gpu, data_count * 2, MPI_DOUBLE, 0, 0, MPI_COMM_WORLD));
        
        MPI_Iscatterv(NULL, NULL, NULL, MPI_DOUBLE, out, all_len[mpi_rank], MPI_DOUBLE, 0, comm, &req);
        MPI_Wait(&req, MPI_STATUS_IGNORE);

    }    
}

void rocfft_mpi_destroy_plan(rocfft_plan *plan, int src_dev, int rank)
{
    if (rank == 0)
        rocfft_plan_destroy(*plan);
    ROCM_CHECK(hipSetDevice(src_dev));
}

void MPIFFT_NEW(HPCC_Params *params, int doIO, FILE *outFile, MPI_Comm comm, int locN,
                double *UGflops, s64Int_t *Un, double *UmaxErr, int *Ufailure)
{
    int commRank, commSize, failure, flags;
    s64Int_t i, n;
    s64Int_t locn, loc0, alocn, aloc0, tls;
    double maxErr, tmp1, tmp2, tmp3, t0, t1, t2, t3, Gflops;
    double deps;
    int sAbort, rAbort;

    struct FFTPlan1D plan, iplan;
    rocfft_plan rocplan, irocplan;
    int src_dev;
    Complex *inout=NULL, *work=NULL, *all_work=NULL;
    Complex *inout_d=NULL, *work_d=NULL, *total_data=NULL;

    failure = 1;
    Gflops = -1.0;
    deps = HPL_dlamch(HPL_MACH_EPS);
    maxErr = 1.0 / deps;

    MPI_Comm_size(comm, &commSize);
    MPI_Comm_rank(comm, &commRank);

    n = locN;

    /* number of processes have been factored out - need to put it back in */
    n *= commSize;

    n *= commSize; /* global vector size */

    t1 = -MPI_Wtime();
    fft_mpi_create_plan(&plan, comm, n, FORWARD, &src_dev);
    t1 += MPI_Wtime();


    if (commRank != commSize - 1) {
        tls = ceil((double)n / commSize);
    }
    else {
        tls = n - ceil((double)n / commSize) * (commSize - 1);
    }

    inout = (Complex *)malloc(tls * (sizeof *inout));
    work = (Complex *)malloc(tls * (sizeof *work));

    ROCM_CHECK(hipMalloc(&inout_d, tls * (sizeof *inout_d)));
    ROCM_CHECK(hipMalloc(&work_d, tls * (sizeof *work_d)));
    if (commRank == 0) {
        ROCM_CHECK(hipMalloc(&total_data, n * (sizeof *total_data)));
    }

    /* Make sure that `inout' and `work' are initialized in parallel if using
     Open MP: this will ensure better placement of pages if first-touch policy
     is used by a distrubuted shared memory machine. */
#ifdef _OPENMP
#pragma omp parallel for
    for (i = 0; i < tls; ++i)
    {
        c_re(inout[i]) = c_re(work[i]) = 0.0;
        c_re(inout[i]) = c_im(work[i]) = 0.0;
    }
#endif

    t0 = -MPI_Wtime();
    HPCC_bcnrand(2 * tls, 53 * commRank * 2 * tls, inout);
    t0 += MPI_Wtime();
    ROCM_CHECK(hipMemcpyHtoD(inout_d, inout, tls * (sizeof *inout)));

    // Warm up
    fft_mpi(&plan, inout_d, work_d, total_data, comm, n);
    fft_mpi(&plan, inout_d, work_d, total_data, comm, n);
    fft_mpi(&plan, inout_d, work_d, total_data, comm, n);

    t2 = -MPI_Wtime();
    fft_mpi(&plan, inout_d, work_d, total_data, comm, n);
    t2 += MPI_Wtime();

    plan.inBuffer = NULL;
    fft_mpi_destroy_plan(&plan, src_dev, commRank);

    fft_mpi_create_plan(&iplan, comm, n, INVERSE, &src_dev);


    t3 = -MPI_Wtime();
    fft_mpi(&iplan, work_d, inout_d, total_data, comm, n);
    t3 += MPI_Wtime();

    ROCM_CHECK(hipMemcpyDtoH(inout, inout_d, tls * (sizeof *inout)));
    fft_mpi_destroy_plan(&iplan, src_dev, commRank);

    // HPCC_bcnrand(2 * tls, 53 * commRank * 2 * tls, work); /* regenerate data */

    all_work = (Complex*)malloc(n * sizeof(Complex));
    for (int i = 0; i < commSize; ++i) {
        HPCC_bcnrand(2 * tls, 53 * i * 2 * tls, all_work + i * tls); /* regenerate data */
    }
    for (int i = 1; i < n; ++i) {
        double tmp1 = all_work[n - i][0], tmp2 = all_work[n - i][1];
        all_work[n - i][0] = all_work[i][0];
        all_work[n - i][1] = all_work[i][1];
        all_work[i][0] = tmp1;
        all_work[i][1] = tmp2;
    }
    memcpy(work, all_work + commRank * tls, tls * sizeof(Complex));

    maxErr = 0.0;
    for (i = 0; i < locN; ++i)
    {
        tmp1 = c_re(inout[i]) / n - c_re(work[i]);
        tmp2 = c_im(inout[i]) / n - c_im(work[i]);
        tmp3 = sqrt(tmp1 * tmp1 + tmp2 * tmp2);
        maxErr = maxErr >= tmp3 ? maxErr : tmp3;
    }
    // printf("------rank %d, max error: %lf------\n", commRank, maxErr);
    MPI_Allreduce(&maxErr, UmaxErr, 1, MPI_DOUBLE, MPI_MAX, comm);
    maxErr = *UmaxErr;
    if (maxErr / log(n) / deps < params->test.thrsh)
        failure = 0;

    if (t2 > 0.0)
        Gflops = 1e-9 * (5.0 * n * log(n) / log(2.0)) / t2;

    if (doIO)
    {
        fprintf(outFile, "Number of nodes: %d\n", commSize);
        fprintf(outFile, "Vector size: %20.0f\n", tmp1 = (double)n);
        fprintf(outFile, "Generation time: %9.3f\n", t0);
        fprintf(outFile, "Tuning: %9.3f\n", t1);
        fprintf(outFile, "Computing: %9.3f\n", t2);
        fprintf(outFile, "Inverse FFT: %9.3f\n", t3);
        fprintf(outFile, "max(|x-x0|): %9.3e\n", maxErr);
        fprintf(outFile, "Gflop/s: %9.3f\n", Gflops);
    }

// comp_end:

    if (work)
        free(work);
    if (inout)
        free(inout);
    if (all_work)
        free(all_work);
    if (work_d)
        ROCM_CHECK(hipFree(work_d));
    if (inout_d)
        ROCM_CHECK(hipFree(inout_d));

no_plan:

    *UGflops = Gflops;
    *Un = n;
    *UmaxErr = maxErr;
    *Ufailure = failure;
}

void ROCFFT_MPI_NEW(HPCC_Params *params, int doIO, FILE *outFile, MPI_Comm comm, int locN, double *UGflops, s64Int_t *Un, double *UmaxErr, int *Ufailure)
{
    int commRank, commSize, failure, flags;
    s64Int_t i, n;
    s64Int_t locn, loc0, alocn, aloc0, tls;
    double maxErr, tmp1, tmp2, tmp3, t0, t1, t2, t3, Gflops;
    double deps;

    int sAbort, rAbort;

    rocfft_plan rocplan, irocplan;
    int src_dev;
    Complex *inout, *work;
    Complex *inout_d=NULL, *work_d=NULL, *total_data=NULL;

    failure = 1;
    Gflops = -1.0;
    deps = HPL_dlamch(HPL_MACH_EPS);
    maxErr = 1.0 / deps;

    MPI_Comm_size(comm, &commSize);
    MPI_Comm_rank(comm, &commRank);

    n = locN;

    /* number of processes have been factored out - need to put it back in */
    n *= commSize;

    n *= commSize; /* global vector size */

    t1 = -MPI_Wtime();
    rocfft_mpi_create_plan(&rocplan, comm, n, rocfft_transform_type_complex_forward, &src_dev);
    t1 += MPI_Wtime();

    if (commRank != commSize - 1) {
        tls = ceil((double)n / commSize);
    }
    else {
        tls = n - ceil((double)n / commSize) * (commSize - 1);
    }

    inout = (Complex *)malloc(tls * (sizeof *inout));
    work = (Complex *)malloc(tls * (sizeof *work));

    ROCM_CHECK(hipMalloc(&inout_d, tls * (sizeof *inout_d)));
    ROCM_CHECK(hipMalloc(&work_d, tls * (sizeof *work_d)));
    if (commRank == 0) {
        ROCM_CHECK(hipMalloc(&total_data, n * (sizeof *total_data)));
    }

    /* Make sure that `inout' and `work' are initialized in parallel if using
     Open MP: this will ensure better placement of pages if first-touch policy
     is used by a distrubuted shared memory machine. */
#ifdef _OPENMP
#pragma omp parallel for
    for (i = 0; i < tls; ++i)
    {
        c_re(inout[i]) = c_re(work[i]) = 0.0;
        c_re(inout[i]) = c_im(work[i]) = 0.0;
    }
#endif

    t0 = -MPI_Wtime();
    HPCC_bcnrand(2 * tls, 53 * commRank * 2 * tls, inout);
    ROCM_CHECK(hipMemcpyHtoD(inout_d, inout, tls * (sizeof *inout)));
    t0 += MPI_Wtime();

    // Warm up
    rocfft_mpi(&rocplan, inout_d, work_d, total_data, comm, n);
    rocfft_mpi(&rocplan, inout_d, work_d, total_data, comm, n);

    t2 = -MPI_Wtime();
    rocfft_mpi(&rocplan, inout_d, work_d, total_data, comm, n);
    t2 += MPI_Wtime();

    rocfft_mpi_destroy_plan(&rocplan, src_dev, commRank);

    rocfft_mpi_create_plan(&irocplan, comm, n, rocfft_transform_type_complex_inverse, &src_dev);


    t3 = -MPI_Wtime();

    rocfft_mpi(&irocplan, work_d, inout_d, total_data, comm, n);
    t3 += MPI_Wtime();

    ROCM_CHECK(hipMemcpyDtoH(inout, inout_d, tls * (sizeof *inout)));

    rocfft_mpi_destroy_plan(&irocplan, src_dev, commRank);

    HPCC_bcnrand(2 * tls, 53 * commRank * 2 * tls, work); /* regenerate data */

    maxErr = 0.0;
    for (i = 0; i < locN; ++i)
    {
        tmp1 = c_re(inout[i]) / n - c_re(work[i]);
        tmp2 = c_im(inout[i]) / n - c_im(work[i]);
        tmp3 = sqrt(tmp1 * tmp1 + tmp2 * tmp2);
        maxErr = maxErr >= tmp3 ? maxErr : tmp3;
    }
    MPI_Allreduce(&maxErr, UmaxErr, 1, MPI_DOUBLE, MPI_MAX, comm);
    maxErr = *UmaxErr;
    if (maxErr / log(n) / deps < params->test.thrsh)
        failure = 0;

    if (t2 > 0.0)
        Gflops = 1e-9 * (5.0 * n * log(n) / log(2.0)) / t2;

    if (doIO)
    {
        fprintf(outFile, "Number of nodes: %d\n", commSize);
        fprintf(outFile, "Vector size: %20.0f\n", tmp1 = (double)n);
        fprintf(outFile, "Generation time: %9.3f\n", t0);
        fprintf(outFile, "Tuning: %9.3f\n", t1);
        fprintf(outFile, "Computing: %9.3f\n", t2);
        fprintf(outFile, "Inverse FFT: %9.3f\n", t3);
        fprintf(outFile, "max(|x-x0|): %9.3e\n", maxErr);
        fprintf(outFile, "Gflop/s: %9.3f\n", Gflops);
    }

// comp_end:

    if (work)
        free(work);
    if (inout)
        free(inout);
    if (work_d)
        ROCM_CHECK(hipFree(work_d));
    if (inout_d)
        ROCM_CHECK(hipFree(inout_d));

no_plan:

    *UGflops = Gflops;
    *Un = n;
    *UmaxErr = maxErr;
    *Ufailure = failure;    
}