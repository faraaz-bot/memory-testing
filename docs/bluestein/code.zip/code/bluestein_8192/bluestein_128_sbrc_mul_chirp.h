#ifndef BLUESTEIN_128_SBRC_MUL_CHIRP_H
#define BLUESTEIN_128_SBRC_MUL_CHIRP_H

#include "bluestein.h"
#include "../rocfft/butterfly_constant.h"
#include "../rocfft/common.h"
#include "../rocfft/real2complex_device.h"
#include "../rocfft/rocfft_butterfly_template.h"
#include <hip/hip_runtime.h>

template <typename scalar_type, StrideBin sb>
__device__ void lds_to_reg_input_length128_mul_chirp_device(scalar_type *R,
                                                            scalar_type *__restrict__ lds_complex,
                                                            unsigned int stride_lds,
                                                            unsigned int offset_lds,
                                                            unsigned int thread,
                                                            bool write)
{
    const unsigned int lstride = (sb == SB_UNIT) ? (1) : (stride_lds);
    unsigned int l_offset;
    __syncthreads();
    l_offset = offset_lds + ((thread + 0 + 0) + 0) * lstride;
    R[0] = lds_complex[l_offset];
    l_offset = offset_lds + ((thread + 0 + 0) + 16) * lstride;
    R[1] = lds_complex[l_offset];
    l_offset = offset_lds + ((thread + 0 + 0) + 32) * lstride;
    R[2] = lds_complex[l_offset];
    l_offset = offset_lds + ((thread + 0 + 0) + 48) * lstride;
    R[3] = lds_complex[l_offset];
    l_offset = offset_lds + ((thread + 0 + 0) + 64) * lstride;
    R[4] = lds_complex[l_offset];
    l_offset = offset_lds + ((thread + 0 + 0) + 80) * lstride;
    R[5] = lds_complex[l_offset];
    l_offset = offset_lds + ((thread + 0 + 0) + 96) * lstride;
    R[6] = lds_complex[l_offset];
    l_offset = offset_lds + ((thread + 0 + 0) + 112) * lstride;
    R[7] = lds_complex[l_offset];
}
template <typename scalar_type, StrideBin sb>
__device__ void lds_from_reg_output_length128_mul_chirp_device(scalar_type *R,
                                                               scalar_type *__restrict__ lds_complex,
                                                               unsigned int stride_lds,
                                                               unsigned int offset_lds,
                                                               unsigned int thread,
                                                               bool write)
{
    const unsigned int lstride = (sb == SB_UNIT) ? (1) : (stride_lds);
    unsigned int l_offset;
    __syncthreads();
    l_offset = offset_lds + (((thread + 0 + 0) / 32) * 128 + (thread + 0 + 0) % 32 + 0) * lstride;
    lds_complex[l_offset] = R[0];
    l_offset = offset_lds + (((thread + 0 + 0) / 32) * 128 + (thread + 0 + 0) % 32 + 32) * lstride;
    lds_complex[l_offset] = R[1];
    l_offset = offset_lds + (((thread + 0 + 0) / 32) * 128 + (thread + 0 + 0) % 32 + 64) * lstride;
    lds_complex[l_offset] = R[2];
    l_offset = offset_lds + (((thread + 0 + 0) / 32) * 128 + (thread + 0 + 0) % 32 + 96) * lstride;
    lds_complex[l_offset] = R[3];
    l_offset = offset_lds + (((thread + 0 + 16) / 32) * 128 + (thread + 0 + 16) % 32 + 0) * lstride;
    lds_complex[l_offset] = R[4];
    l_offset = offset_lds + (((thread + 0 + 16) / 32) * 128 + (thread + 0 + 16) % 32 + 32) * lstride;
    lds_complex[l_offset] = R[5];
    l_offset = offset_lds + (((thread + 0 + 16) / 32) * 128 + (thread + 0 + 16) % 32 + 64) * lstride;
    lds_complex[l_offset] = R[6];
    l_offset = offset_lds + (((thread + 0 + 16) / 32) * 128 + (thread + 0 + 16) % 32 + 96) * lstride;
    lds_complex[l_offset] = R[7];
}
template <typename scalar_type,
          const bool lds_is_real,
          SBRC_TYPE sbrc_type,
          SBRC_TRANSPOSE_TYPE transpose_type,
          StrideBin sb,
          const bool lds_linear,
          const bool direct_load_to_reg>
__device__ void inverse_length128_SBRC_mul_chirp_device(scalar_type *R,
                                                        real_type_t<scalar_type> *__restrict__ lds_real,
                                                        scalar_type *__restrict__ lds_complex,
                                                        const scalar_type *__restrict__ twiddles,
                                                        unsigned int stride_lds,
                                                        unsigned int offset_lds,
                                                        unsigned int thread,
                                                        bool write)
{
    scalar_type W;
    scalar_type t;
    const unsigned int lstride = (sb == SB_UNIT) ? (1) : (stride_lds);
    unsigned int l_offset;

    // pass 0, width 8
    // using 16 threads we need to do 16 radix-8 butterflies
    // therefore each thread will do 1.000000 butterflies
    InvRad8B1(R + 0, R + 1, R + 2, R + 3, R + 4, R + 5, R + 6, R + 7);
    if (!lds_is_real)
    {
        if (!direct_load_to_reg)
        {
            __syncthreads();
        }

        l_offset = offset_lds + (((thread + 0 + 0) / 1) * 8 + (thread + 0 + 0) % 1 + 0) * lstride;
        lds_complex[l_offset] = R[0];
        l_offset = offset_lds + (((thread + 0 + 0) / 1) * 8 + (thread + 0 + 0) % 1 + 1) * lstride;
        lds_complex[l_offset] = R[1];
        l_offset = offset_lds + (((thread + 0 + 0) / 1) * 8 + (thread + 0 + 0) % 1 + 2) * lstride;
        lds_complex[l_offset] = R[2];
        l_offset = offset_lds + (((thread + 0 + 0) / 1) * 8 + (thread + 0 + 0) % 1 + 3) * lstride;
        lds_complex[l_offset] = R[3];
        l_offset = offset_lds + (((thread + 0 + 0) / 1) * 8 + (thread + 0 + 0) % 1 + 4) * lstride;
        lds_complex[l_offset] = R[4];
        l_offset = offset_lds + (((thread + 0 + 0) / 1) * 8 + (thread + 0 + 0) % 1 + 5) * lstride;
        lds_complex[l_offset] = R[5];
        l_offset = offset_lds + (((thread + 0 + 0) / 1) * 8 + (thread + 0 + 0) % 1 + 6) * lstride;
        lds_complex[l_offset] = R[6];
        l_offset = offset_lds + (((thread + 0 + 0) / 1) * 8 + (thread + 0 + 0) % 1 + 7) * lstride;
        lds_complex[l_offset] = R[7];
    }

    else
    {
        l_offset = offset_lds + (((thread + 0 + 0) / 1) * 8 + (thread + 0 + 0) % 1 + 0) * lstride;
        lds_real[l_offset] = R[0].x;
        l_offset = offset_lds + (((thread + 0 + 0) / 1) * 8 + (thread + 0 + 0) % 1 + 1) * lstride;
        lds_real[l_offset] = R[1].x;
        l_offset = offset_lds + (((thread + 0 + 0) / 1) * 8 + (thread + 0 + 0) % 1 + 2) * lstride;
        lds_real[l_offset] = R[2].x;
        l_offset = offset_lds + (((thread + 0 + 0) / 1) * 8 + (thread + 0 + 0) % 1 + 3) * lstride;
        lds_real[l_offset] = R[3].x;
        l_offset = offset_lds + (((thread + 0 + 0) / 1) * 8 + (thread + 0 + 0) % 1 + 4) * lstride;
        lds_real[l_offset] = R[4].x;
        l_offset = offset_lds + (((thread + 0 + 0) / 1) * 8 + (thread + 0 + 0) % 1 + 5) * lstride;
        lds_real[l_offset] = R[5].x;
        l_offset = offset_lds + (((thread + 0 + 0) / 1) * 8 + (thread + 0 + 0) % 1 + 6) * lstride;
        lds_real[l_offset] = R[6].x;
        l_offset = offset_lds + (((thread + 0 + 0) / 1) * 8 + (thread + 0 + 0) % 1 + 7) * lstride;
        lds_real[l_offset] = R[7].x;
        __syncthreads();
        l_offset = offset_lds + ((thread + 0 + 0) + 0) * lstride;
        R[0].x = lds_real[l_offset];
        l_offset = offset_lds + ((thread + 0 + 0) + 32) * lstride;
        R[1].x = lds_real[l_offset];
        l_offset = offset_lds + ((thread + 0 + 0) + 64) * lstride;
        R[2].x = lds_real[l_offset];
        l_offset = offset_lds + ((thread + 0 + 0) + 96) * lstride;
        R[3].x = lds_real[l_offset];
        l_offset = offset_lds + ((thread + 0 + 16) + 0) * lstride;
        R[4].x = lds_real[l_offset];
        l_offset = offset_lds + ((thread + 0 + 16) + 32) * lstride;
        R[5].x = lds_real[l_offset];
        l_offset = offset_lds + ((thread + 0 + 16) + 64) * lstride;
        R[6].x = lds_real[l_offset];
        l_offset = offset_lds + ((thread + 0 + 16) + 96) * lstride;
        R[7].x = lds_real[l_offset];
        __syncthreads();
        l_offset = offset_lds + (((thread + 0 + 0) / 1) * 8 + (thread + 0 + 0) % 1 + 0) * lstride;
        lds_real[l_offset] = R[0].y;
        l_offset = offset_lds + (((thread + 0 + 0) / 1) * 8 + (thread + 0 + 0) % 1 + 1) * lstride;
        lds_real[l_offset] = R[1].y;
        l_offset = offset_lds + (((thread + 0 + 0) / 1) * 8 + (thread + 0 + 0) % 1 + 2) * lstride;
        lds_real[l_offset] = R[2].y;
        l_offset = offset_lds + (((thread + 0 + 0) / 1) * 8 + (thread + 0 + 0) % 1 + 3) * lstride;
        lds_real[l_offset] = R[3].y;
        l_offset = offset_lds + (((thread + 0 + 0) / 1) * 8 + (thread + 0 + 0) % 1 + 4) * lstride;
        lds_real[l_offset] = R[4].y;
        l_offset = offset_lds + (((thread + 0 + 0) / 1) * 8 + (thread + 0 + 0) % 1 + 5) * lstride;
        lds_real[l_offset] = R[5].y;
        l_offset = offset_lds + (((thread + 0 + 0) / 1) * 8 + (thread + 0 + 0) % 1 + 6) * lstride;
        lds_real[l_offset] = R[6].y;
        l_offset = offset_lds + (((thread + 0 + 0) / 1) * 8 + (thread + 0 + 0) % 1 + 7) * lstride;
        lds_real[l_offset] = R[7].y;
        __syncthreads();
        l_offset = offset_lds + ((thread + 0 + 0) + 0) * lstride;
        R[0].y = lds_real[l_offset];
        l_offset = offset_lds + ((thread + 0 + 0) + 32) * lstride;
        R[1].y = lds_real[l_offset];
        l_offset = offset_lds + ((thread + 0 + 0) + 64) * lstride;
        R[2].y = lds_real[l_offset];
        l_offset = offset_lds + ((thread + 0 + 0) + 96) * lstride;
        R[3].y = lds_real[l_offset];
        l_offset = offset_lds + ((thread + 0 + 16) + 0) * lstride;
        R[4].y = lds_real[l_offset];
        l_offset = offset_lds + ((thread + 0 + 16) + 32) * lstride;
        R[5].y = lds_real[l_offset];
        l_offset = offset_lds + ((thread + 0 + 16) + 64) * lstride;
        R[6].y = lds_real[l_offset];
        l_offset = offset_lds + ((thread + 0 + 16) + 96) * lstride;
        R[7].y = lds_real[l_offset];
    }

    // pass 1, width 4
    // using 16 threads we need to do 32 radix-4 butterflies
    // therefore each thread will do 2.000000 butterflies
    if (!lds_is_real)
    {
        __syncthreads();
        l_offset = offset_lds + ((thread + 0 + 0) + 0) * lstride;
        R[0] = lds_complex[l_offset];
        l_offset = offset_lds + ((thread + 0 + 0) + 32) * lstride;
        R[1] = lds_complex[l_offset];
        l_offset = offset_lds + ((thread + 0 + 0) + 64) * lstride;
        R[2] = lds_complex[l_offset];
        l_offset = offset_lds + ((thread + 0 + 0) + 96) * lstride;
        R[3] = lds_complex[l_offset];
        l_offset = offset_lds + ((thread + 0 + 16) + 0) * lstride;
        R[4] = lds_complex[l_offset];
        l_offset = offset_lds + ((thread + 0 + 16) + 32) * lstride;
        R[5] = lds_complex[l_offset];
        l_offset = offset_lds + ((thread + 0 + 16) + 64) * lstride;
        R[6] = lds_complex[l_offset];
        l_offset = offset_lds + ((thread + 0 + 16) + 96) * lstride;
        R[7] = lds_complex[l_offset];
    }

    W = twiddles[0 + 3 * ((thread + 0 + 0) % 8)];
    t = {R[1].x * W.x + R[1].y * W.y, R[1].y * W.x - R[1].x * W.y};
    R[1] = t;
    W = twiddles[1 + 3 * ((thread + 0 + 0) % 8)];
    t = {R[2].x * W.x + R[2].y * W.y, R[2].y * W.x - R[2].x * W.y};
    R[2] = t;
    W = twiddles[2 + 3 * ((thread + 0 + 0) % 8)];
    t = {R[3].x * W.x + R[3].y * W.y, R[3].y * W.x - R[3].x * W.y};
    R[3] = t;
    W = twiddles[0 + 3 * ((thread + 0 + 16) % 8)];
    t = {R[5].x * W.x + R[5].y * W.y, R[5].y * W.x - R[5].x * W.y};
    R[5] = t;
    W = twiddles[1 + 3 * ((thread + 0 + 16) % 8)];
    t = {R[6].x * W.x + R[6].y * W.y, R[6].y * W.x - R[6].x * W.y};
    R[6] = t;
    W = twiddles[2 + 3 * ((thread + 0 + 16) % 8)];
    t = {R[7].x * W.x + R[7].y * W.y, R[7].y * W.x - R[7].x * W.y};
    R[7] = t;
    InvRad4B1(R + 0, R + 1, R + 2, R + 3);
    InvRad4B1(R + 4, R + 5, R + 6, R + 7);
    if (!lds_is_real)
    {
        __syncthreads();
        l_offset = offset_lds + (((thread + 0 + 0) / 8) * 32 + (thread + 0 + 0) % 8 + 0) * lstride;
        lds_complex[l_offset] = R[0];
        l_offset = offset_lds + (((thread + 0 + 0) / 8) * 32 + (thread + 0 + 0) % 8 + 8) * lstride;
        lds_complex[l_offset] = R[1];
        l_offset = offset_lds + (((thread + 0 + 0) / 8) * 32 + (thread + 0 + 0) % 8 + 16) * lstride;
        lds_complex[l_offset] = R[2];
        l_offset = offset_lds + (((thread + 0 + 0) / 8) * 32 + (thread + 0 + 0) % 8 + 24) * lstride;
        lds_complex[l_offset] = R[3];
        l_offset = offset_lds + (((thread + 0 + 16) / 8) * 32 + (thread + 0 + 16) % 8 + 0) * lstride;
        lds_complex[l_offset] = R[4];
        l_offset = offset_lds + (((thread + 0 + 16) / 8) * 32 + (thread + 0 + 16) % 8 + 8) * lstride;
        lds_complex[l_offset] = R[5];
        l_offset = offset_lds + (((thread + 0 + 16) / 8) * 32 + (thread + 0 + 16) % 8 + 16) * lstride;
        lds_complex[l_offset] = R[6];
        l_offset = offset_lds + (((thread + 0 + 16) / 8) * 32 + (thread + 0 + 16) % 8 + 24) * lstride;
        lds_complex[l_offset] = R[7];
    }

    else
    {
        __syncthreads();
        l_offset = offset_lds + (((thread + 0 + 0) / 8) * 32 + (thread + 0 + 0) % 8 + 0) * lstride;
        lds_real[l_offset] = R[0].x;
        l_offset = offset_lds + (((thread + 0 + 0) / 8) * 32 + (thread + 0 + 0) % 8 + 8) * lstride;
        lds_real[l_offset] = R[1].x;
        l_offset = offset_lds + (((thread + 0 + 0) / 8) * 32 + (thread + 0 + 0) % 8 + 16) * lstride;
        lds_real[l_offset] = R[2].x;
        l_offset = offset_lds + (((thread + 0 + 0) / 8) * 32 + (thread + 0 + 0) % 8 + 24) * lstride;
        lds_real[l_offset] = R[3].x;
        l_offset = offset_lds + (((thread + 0 + 16) / 8) * 32 + (thread + 0 + 16) % 8 + 0) * lstride;
        lds_real[l_offset] = R[4].x;
        l_offset = offset_lds + (((thread + 0 + 16) / 8) * 32 + (thread + 0 + 16) % 8 + 8) * lstride;
        lds_real[l_offset] = R[5].x;
        l_offset = offset_lds + (((thread + 0 + 16) / 8) * 32 + (thread + 0 + 16) % 8 + 16) * lstride;
        lds_real[l_offset] = R[6].x;
        l_offset = offset_lds + (((thread + 0 + 16) / 8) * 32 + (thread + 0 + 16) % 8 + 24) * lstride;
        lds_real[l_offset] = R[7].x;
        __syncthreads();
        l_offset = offset_lds + ((thread + 0 + 0) + 0) * lstride;
        R[0].x = lds_real[l_offset];
        l_offset = offset_lds + ((thread + 0 + 0) + 32) * lstride;
        R[1].x = lds_real[l_offset];
        l_offset = offset_lds + ((thread + 0 + 0) + 64) * lstride;
        R[2].x = lds_real[l_offset];
        l_offset = offset_lds + ((thread + 0 + 0) + 96) * lstride;
        R[3].x = lds_real[l_offset];
        l_offset = offset_lds + ((thread + 0 + 16) + 0) * lstride;
        R[4].x = lds_real[l_offset];
        l_offset = offset_lds + ((thread + 0 + 16) + 32) * lstride;
        R[5].x = lds_real[l_offset];
        l_offset = offset_lds + ((thread + 0 + 16) + 64) * lstride;
        R[6].x = lds_real[l_offset];
        l_offset = offset_lds + ((thread + 0 + 16) + 96) * lstride;
        R[7].x = lds_real[l_offset];
        __syncthreads();
        l_offset = offset_lds + (((thread + 0 + 0) / 8) * 32 + (thread + 0 + 0) % 8 + 0) * lstride;
        lds_real[l_offset] = R[0].y;
        l_offset = offset_lds + (((thread + 0 + 0) / 8) * 32 + (thread + 0 + 0) % 8 + 8) * lstride;
        lds_real[l_offset] = R[1].y;
        l_offset = offset_lds + (((thread + 0 + 0) / 8) * 32 + (thread + 0 + 0) % 8 + 16) * lstride;
        lds_real[l_offset] = R[2].y;
        l_offset = offset_lds + (((thread + 0 + 0) / 8) * 32 + (thread + 0 + 0) % 8 + 24) * lstride;
        lds_real[l_offset] = R[3].y;
        l_offset = offset_lds + (((thread + 0 + 16) / 8) * 32 + (thread + 0 + 16) % 8 + 0) * lstride;
        lds_real[l_offset] = R[4].y;
        l_offset = offset_lds + (((thread + 0 + 16) / 8) * 32 + (thread + 0 + 16) % 8 + 8) * lstride;
        lds_real[l_offset] = R[5].y;
        l_offset = offset_lds + (((thread + 0 + 16) / 8) * 32 + (thread + 0 + 16) % 8 + 16) * lstride;
        lds_real[l_offset] = R[6].y;
        l_offset = offset_lds + (((thread + 0 + 16) / 8) * 32 + (thread + 0 + 16) % 8 + 24) * lstride;
        lds_real[l_offset] = R[7].y;
        __syncthreads();
        l_offset = offset_lds + ((thread + 0 + 0) + 0) * lstride;
        R[0].y = lds_real[l_offset];
        l_offset = offset_lds + ((thread + 0 + 0) + 32) * lstride;
        R[1].y = lds_real[l_offset];
        l_offset = offset_lds + ((thread + 0 + 0) + 64) * lstride;
        R[2].y = lds_real[l_offset];
        l_offset = offset_lds + ((thread + 0 + 0) + 96) * lstride;
        R[3].y = lds_real[l_offset];
        l_offset = offset_lds + ((thread + 0 + 16) + 0) * lstride;
        R[4].y = lds_real[l_offset];
        l_offset = offset_lds + ((thread + 0 + 16) + 32) * lstride;
        R[5].y = lds_real[l_offset];
        l_offset = offset_lds + ((thread + 0 + 16) + 64) * lstride;
        R[6].y = lds_real[l_offset];
        l_offset = offset_lds + ((thread + 0 + 16) + 96) * lstride;
        R[7].y = lds_real[l_offset];
    }

    // pass 2, width 4
    // using 16 threads we need to do 32 radix-4 butterflies
    // therefore each thread will do 2.000000 butterflies
    if (!lds_is_real)
    {
        __syncthreads();
        l_offset = offset_lds + ((thread + 0 + 0) + 0) * lstride;
        R[0] = lds_complex[l_offset];
        l_offset = offset_lds + ((thread + 0 + 0) + 32) * lstride;
        R[1] = lds_complex[l_offset];
        l_offset = offset_lds + ((thread + 0 + 0) + 64) * lstride;
        R[2] = lds_complex[l_offset];
        l_offset = offset_lds + ((thread + 0 + 0) + 96) * lstride;
        R[3] = lds_complex[l_offset];
        l_offset = offset_lds + ((thread + 0 + 16) + 0) * lstride;
        R[4] = lds_complex[l_offset];
        l_offset = offset_lds + ((thread + 0 + 16) + 32) * lstride;
        R[5] = lds_complex[l_offset];
        l_offset = offset_lds + ((thread + 0 + 16) + 64) * lstride;
        R[6] = lds_complex[l_offset];
        l_offset = offset_lds + ((thread + 0 + 16) + 96) * lstride;
        R[7] = lds_complex[l_offset];
    }

    W = twiddles[24 + 3 * ((thread + 0 + 0) % 32)];
    t = {R[1].x * W.x + R[1].y * W.y, R[1].y * W.x - R[1].x * W.y};
    R[1] = t;
    W = twiddles[25 + 3 * ((thread + 0 + 0) % 32)];
    t = {R[2].x * W.x + R[2].y * W.y, R[2].y * W.x - R[2].x * W.y};
    R[2] = t;
    W = twiddles[26 + 3 * ((thread + 0 + 0) % 32)];
    t = {R[3].x * W.x + R[3].y * W.y, R[3].y * W.x - R[3].x * W.y};
    R[3] = t;
    W = twiddles[24 + 3 * ((thread + 0 + 16) % 32)];
    t = {R[5].x * W.x + R[5].y * W.y, R[5].y * W.x - R[5].x * W.y};
    R[5] = t;
    W = twiddles[25 + 3 * ((thread + 0 + 16) % 32)];
    t = {R[6].x * W.x + R[6].y * W.y, R[6].y * W.x - R[6].x * W.y};
    R[6] = t;
    W = twiddles[26 + 3 * ((thread + 0 + 16) % 32)];
    t = {R[7].x * W.x + R[7].y * W.y, R[7].y * W.x - R[7].x * W.y};
    R[7] = t;
    InvRad4B1(R + 0, R + 1, R + 2, R + 3);
    InvRad4B1(R + 4, R + 5, R + 6, R + 7);
}
template <typename scalar_type>
__global__
    __launch_bounds__(128) void op_inverse_length128_SBRC_mul_chirp(const scalar_type *__restrict__ twiddles,
                                                                    const size_t dim,
                                                                    const size_t N,
                                                                    const size_t *__restrict__ lengths,
                                                                    const size_t *__restrict__ stride_in,
                                                                    const size_t *__restrict__ stride_out,
                                                                    const size_t nbatch,
                                                                    const unsigned int lds_padding,
                                                                    void *__restrict__ load_cb_fn,
                                                                    void *__restrict__ load_cb_data,
                                                                    unsigned int load_cb_lds_bytes,
                                                                    void *__restrict__ store_cb_fn,
                                                                    void *__restrict__ store_cb_data,
                                                                    scalar_type *__restrict__ buf_in,
                                                                    scalar_type *__restrict__ buf_out,
                                                                    const scalar_type *__restrict__ chirp_buf,
                                                                    scalar_type *__restrict__ buf_tmp)
{
    auto const sb = StrideBin::SB_NONUNIT;
    auto const ebtype = EmbeddedType::NONE;
    auto const drtype = DirectRegType::FORCE_OFF_OR_NOT_SUPPORT;

    auto const sbrc_type = SBRC_TYPE::SBRC_2D;
    auto const transpose_type = SBRC_TRANSPOSE_TYPE::NONE;

    // this kernel:
    //   uses 16 threads per transform
    //   does 8 transforms per thread block
    // therefore it should be called with 128 threads per thread block
    scalar_type R[8];
    extern __shared__ unsigned char __attribute__((aligned(sizeof(scalar_type)))) lds_uchar[];
    real_type_t<scalar_type> *__restrict__ lds_real = reinterpret_cast<real_type_t<scalar_type> *>(lds_uchar);
    scalar_type *__restrict__ lds_complex = reinterpret_cast<scalar_type *>(lds_uchar);
    size_t offset_in = 0;
    size_t offset_out = 0;
    unsigned int offset_lds;
    unsigned int stride_lds;
    size_t batch;
    size_t transform;
    const bool direct_load_to_reg = false;
    const bool direct_store_from_reg = drtype == DirectRegType::TRY_ENABLE_IF_SUPPORT && sbrc_type != SBRC_3D_FFT_ERC_TRANS_Z_XY;
    const bool lds_linear = !direct_store_from_reg;
    const bool lds_is_real = false;
    auto load_cb = get_load_cb<scalar_type, CallbackType::NONE>(load_cb_fn);
    auto store_cb = get_store_cb<scalar_type, CallbackType::NONE>(store_cb_fn);

    // large twiddles
    // - no large twiddles

    // offsets
    const size_t stride0_in = (sb == SB_UNIT) ? (1) : (stride_in[0]);
    const size_t stride0_out = (sb == SB_UNIT) ? (1) : (stride_out[0]);
    const unsigned int len_along_block = (sbrc_type == SBRC_3D_FFT_TRANS_XY_Z) ? lengths[2] : lengths[1];
    const unsigned int stride_load_in = (sbrc_type == SBRC_3D_FFT_TRANS_XY_Z) ? stride_in[2] : stride_in[1];
    const unsigned int stride_store_out = (sbrc_type == SBRC_3D_FFT_TRANS_XY_Z || sbrc_type == SBRC_2D) ? stride_out[1]
                                                                                                        : stride_out[2];

    scalar_type aux_scalar;
    real_type_t<scalar_type> aux_real;
    size_t M = 1;
    size_t tx;
    for (int d = 0; d < dim; ++d)
    {
        M *= lengths[d];
    }
    BluesteinData<scalar_type> blue_data;
    blue_data.length_M = M;
    blue_data.length_N = N;
    blue_data.buf_chirp = chirp_buf;
    blue_data.buf_tmp = buf_tmp;
    blue_data.access_mode = BluesteinBufferAccessMode::ALL;

    unsigned int num_of_tiles_in_batch;
    unsigned int tile_index_in_plane;

    unsigned int num_of_tiles_in_plane = (len_along_block - 1) / 8 + 1;
    unsigned int plane_id;
    unsigned int tile_serial_in_batch;
    if (sbrc_type == SBRC_2D)
    {
        num_of_tiles_in_batch = num_of_tiles_in_plane;
        tile_index_in_plane = blockIdx.x % num_of_tiles_in_plane;
        unsigned int remaining = blockIdx.x / num_of_tiles_in_plane;
        unsigned int index_along_d;
        offset_in = tile_index_in_plane * 8 * stride_load_in;
        offset_out = tile_index_in_plane * 8 * stride0_out;
        for (unsigned int d = 2; d < dim; ++d)
        {
            num_of_tiles_in_batch = num_of_tiles_in_batch * lengths[d];
            index_along_d = remaining % lengths[d];
            remaining = remaining / lengths[d];
            offset_in = offset_in + index_along_d * stride_in[d];
            offset_out = offset_out + index_along_d * stride_out[d];
        }
    }

    else
    {
        const unsigned int len_along_plane = (sbrc_type == SBRC_3D_FFT_TRANS_XY_Z) ? lengths[1] : lengths[2];
        const unsigned int stride_plane_in = (sbrc_type == SBRC_3D_FFT_TRANS_XY_Z) ? stride_in[1] : stride_in[2];
        const unsigned int stride_plane_out = (sbrc_type == SBRC_3D_FFT_TRANS_XY_Z) ? stride_out[2] : stride_out[1];
        num_of_tiles_in_batch = num_of_tiles_in_plane * len_along_plane;
        tile_serial_in_batch = blockIdx.x % num_of_tiles_in_batch;
        if (sbrc_type == SBRC_3D_FFT_TRANS_XY_Z)
        {
            if (transpose_type == DIAGONAL)
            {
                tile_index_in_plane = tile_serial_in_batch % 16;
                plane_id = (tile_serial_in_batch / 16 + tile_index_in_plane) % 128;
            }

            else
            {
                tile_index_in_plane = tile_serial_in_batch / lengths[1];
                plane_id = blockIdx.x % lengths[1];
            }
        }

        else
        {
            if (transpose_type == DIAGONAL)
            {
                tile_index_in_plane = tile_serial_in_batch % 16;
                plane_id = (tile_serial_in_batch / 16 + tile_index_in_plane) % 128;
            }

            else
            {
                plane_id = tile_serial_in_batch / num_of_tiles_in_plane;
                tile_index_in_plane = blockIdx.x % num_of_tiles_in_plane;
            }
        }

        offset_in = plane_id * stride_plane_in + tile_index_in_plane * 8 * stride_load_in;
        offset_out = plane_id * stride_plane_out + tile_index_in_plane * 8 * stride0_out;
    }

    batch = blockIdx.x / num_of_tiles_in_batch;
    offset_in = offset_in + batch * stride_in[dim];
    offset_out = offset_out + batch * stride_out[dim];
    transform = lds_linear ? tile_index_in_plane * 8 + threadIdx.x / 16
                           : tile_index_in_plane * 8 + threadIdx.x % 8;
    stride_lds = lds_linear ? 128 + (sbrc_type != SBRC_3D_FFT_ERC_TRANS_Z_XY ? 0 : lds_padding)
                            : 8 + (sbrc_type != SBRC_3D_FFT_ERC_TRANS_Z_XY ? 0 : lds_padding);
    offset_lds = lds_linear ? stride_lds * (transform % 8) : threadIdx.x % 8;
    bool edge = false;
    unsigned int thread;
    unsigned int tid_hor;
    if (transpose_type == TILE_UNALIGNED)
    {
        edge = ((tile_index_in_plane + 1) * 8 > len_along_block) ? true : false;
    }

    if (direct_load_to_reg)
    {
        // load global into registers
        // For row-input we don't load to reg
    }

    else
    {
        // load global into lds
        thread = threadIdx.x / 128;
        tid_hor = threadIdx.x % 128;
        if (transpose_type != TILE_UNALIGNED || !edge)
        {
            // TODO: Here
            tx = offset_in + (tid_hor * stride0_in + (thread + 0) * stride_load_in);
            blue_data.transform_index = tx;
            lds_complex[lds_linear ? tid_hor * 1 + (thread + 0) * stride_lds
                                   : tid_hor * stride_lds + (thread + 0) * 1] = bluestein_load_tmp(buf_in,
                                                                                                   tx,
                                                                                                   &blue_data,
                                                                                                   nullptr);

            tx = offset_in + (tid_hor * stride0_in + (thread + 1) * stride_load_in);
            blue_data.transform_index = tx;
            lds_complex[lds_linear ? tid_hor * 1 + (thread + 1) * stride_lds
                                   : tid_hor * stride_lds + (thread + 1) * 1] = bluestein_load_tmp(buf_in,
                                                                                                   tx,
                                                                                                   &blue_data,
                                                                                                   nullptr);

            tx = offset_in + (tid_hor * stride0_in + (thread + 2) * stride_load_in);
            blue_data.transform_index = tx;
            lds_complex[lds_linear ? tid_hor * 1 + (thread + 2) * stride_lds
                                   : tid_hor * stride_lds + (thread + 2) * 1] = bluestein_load_tmp(buf_in,
                                                                                                   tx,
                                                                                                   &blue_data,
                                                                                                   nullptr);

            tx = offset_in + (tid_hor * stride0_in + (thread + 3) * stride_load_in);
            blue_data.transform_index = tx;
            lds_complex[lds_linear ? tid_hor * 1 + (thread + 3) * stride_lds
                                   : tid_hor * stride_lds + (thread + 3) * 1] = bluestein_load_tmp(buf_in,
                                                                                                   tx,
                                                                                                   &blue_data,
                                                                                                   nullptr);

            tx = offset_in + (tid_hor * stride0_in + (thread + 4) * stride_load_in);
            blue_data.transform_index = tx;
            lds_complex[lds_linear ? tid_hor * 1 + (thread + 4) * stride_lds
                                   : tid_hor * stride_lds + (thread + 4) * 1] = bluestein_load_tmp(buf_in,
                                                                                                   tx,
                                                                                                   &blue_data,
                                                                                                   nullptr);

            tx = offset_in + (tid_hor * stride0_in + (thread + 5) * stride_load_in);
            blue_data.transform_index = tx;
            lds_complex[lds_linear ? tid_hor * 1 + (thread + 5) * stride_lds
                                   : tid_hor * stride_lds + (thread + 5) * 1] = bluestein_load_tmp(buf_in,
                                                                                                   tx,
                                                                                                   &blue_data,
                                                                                                   nullptr);

            tx = offset_in + (tid_hor * stride0_in + (thread + 6) * stride_load_in);
            blue_data.transform_index = tx;
            lds_complex[lds_linear ? tid_hor * 1 + (thread + 6) * stride_lds
                                   : tid_hor * stride_lds + (thread + 6) * 1] = bluestein_load_tmp(buf_in,
                                                                                                   tx,
                                                                                                   &blue_data,
                                                                                                   nullptr);

            tx = offset_in + (tid_hor * stride0_in + (thread + 7) * stride_load_in);
            blue_data.transform_index = tx;
            lds_complex[lds_linear ? tid_hor * 1 + (thread + 7) * stride_lds
                                   : tid_hor * stride_lds + (thread + 7) * 1] = bluestein_load_tmp(buf_in,
                                                                                                   tx,
                                                                                                   &blue_data,
                                                                                                   nullptr);
        }

        else
        {
            for (unsigned int t = 0; tile_index_in_plane * 8 + thread + t < len_along_block; ++t)
            {
                lds_complex[lds_linear ? tid_hor * 1 + (thread + t) * stride_lds
                                       : tid_hor * stride_lds + (thread + t) * 1] = load_cb(buf_in,
                                                                                            offset_in + (tid_hor * stride0_in + (thread + t) * stride_load_in),
                                                                                            load_cb_data,
                                                                                            nullptr);
            }
        }
    }

    // calc the thread_in_device value once and for all device funcs
    unsigned int thread_in_device = lds_linear ? threadIdx.x % 16 : threadIdx.x / 8;

    // call a pre-load from lds to registers (if necessary)
    if (!direct_load_to_reg)
    {
        lds_to_reg_input_length128_mul_chirp_device<scalar_type, lds_linear ? SB_UNIT : SB_NONUNIT>(
            R, lds_complex, stride_lds, offset_lds, thread_in_device, true);
    }

    // transform
    inverse_length128_SBRC_mul_chirp_device<scalar_type,
                                            lds_is_real,
                                            sbrc_type,
                                            transpose_type,
                                            lds_linear ? SB_UNIT : SB_NONUNIT,
                                            lds_linear,
                                            direct_load_to_reg>(
        R, lds_real, lds_complex, twiddles, stride_lds, offset_lds, thread_in_device, true);

    // call a post-store from registers to lds (if necessary)
    if (!direct_store_from_reg)
    {
        lds_from_reg_output_length128_mul_chirp_device<scalar_type, lds_linear ? SB_UNIT : SB_NONUNIT>(
            R, lds_complex, stride_lds, offset_lds, thread_in_device, true);
    }

    if (direct_store_from_reg)
    {
        // store registers into global
        thread = threadIdx.x / 8;
        tid_hor = threadIdx.x % 8;
        if (transpose_type != TILE_UNALIGNED || !edge)
        {
            store_cb(buf_out,
                     offset_out + tid_hor * stride0_out + (((thread + 0 + 0) / 32) * 128 + (thread + 0 + 0) % 32 + 0) * stride_store_out,
                     R[0],
                     store_cb_data,
                     nullptr);
            store_cb(buf_out,
                     offset_out + tid_hor * stride0_out + (((thread + 0 + 0) / 32) * 128 + (thread + 0 + 0) % 32 + 32) * stride_store_out,
                     R[1],
                     store_cb_data,
                     nullptr);
            store_cb(buf_out,
                     offset_out + tid_hor * stride0_out + (((thread + 0 + 0) / 32) * 128 + (thread + 0 + 0) % 32 + 64) * stride_store_out,
                     R[2],
                     store_cb_data,
                     nullptr);
            store_cb(buf_out,
                     offset_out + tid_hor * stride0_out + (((thread + 0 + 0) / 32) * 128 + (thread + 0 + 0) % 32 + 96) * stride_store_out,
                     R[3],
                     store_cb_data,
                     nullptr);
            store_cb(buf_out,
                     offset_out + tid_hor * stride0_out + (((thread + 0 + 16) / 32) * 128 + (thread + 0 + 16) % 32 + 0) * stride_store_out,
                     R[4],
                     store_cb_data,
                     nullptr);
            store_cb(buf_out,
                     offset_out + tid_hor * stride0_out + (((thread + 0 + 16) / 32) * 128 + (thread + 0 + 16) % 32 + 32) * stride_store_out,
                     R[5],
                     store_cb_data,
                     nullptr);
            store_cb(buf_out,
                     offset_out + tid_hor * stride0_out + (((thread + 0 + 16) / 32) * 128 + (thread + 0 + 16) % 32 + 64) * stride_store_out,
                     R[6],
                     store_cb_data,
                     nullptr);
            store_cb(buf_out,
                     offset_out + tid_hor * stride0_out + (((thread + 0 + 16) / 32) * 128 + (thread + 0 + 16) % 32 + 96) * stride_store_out,
                     R[7],
                     store_cb_data,
                     nullptr);
        }

        else
        {
            if (tile_index_in_plane * 8 + tid_hor < len_along_block)
            {
                store_cb(buf_out,
                         offset_out + tid_hor * stride0_out + (((thread + 0 + 0) / 32) * 128 + (thread + 0 + 0) % 32 + 0) * stride_store_out,
                         R[0],
                         store_cb_data,
                         nullptr);
                store_cb(buf_out,
                         offset_out + tid_hor * stride0_out + (((thread + 0 + 0) / 32) * 128 + (thread + 0 + 0) % 32 + 32) * stride_store_out,
                         R[1],
                         store_cb_data,
                         nullptr);
                store_cb(buf_out,
                         offset_out + tid_hor * stride0_out + (((thread + 0 + 0) / 32) * 128 + (thread + 0 + 0) % 32 + 64) * stride_store_out,
                         R[2],
                         store_cb_data,
                         nullptr);
                store_cb(buf_out,
                         offset_out + tid_hor * stride0_out + (((thread + 0 + 0) / 32) * 128 + (thread + 0 + 0) % 32 + 96) * stride_store_out,
                         R[3],
                         store_cb_data,
                         nullptr);
                store_cb(buf_out,
                         offset_out + tid_hor * stride0_out + (((thread + 0 + 16) / 32) * 128 + (thread + 0 + 16) % 32 + 0) * stride_store_out,
                         R[4],
                         store_cb_data,
                         nullptr);
                store_cb(buf_out,
                         offset_out + tid_hor * stride0_out + (((thread + 0 + 16) / 32) * 128 + (thread + 0 + 16) % 32 + 32) * stride_store_out,
                         R[5],
                         store_cb_data,
                         nullptr);
                store_cb(buf_out,
                         offset_out + tid_hor * stride0_out + (((thread + 0 + 16) / 32) * 128 + (thread + 0 + 16) % 32 + 64) * stride_store_out,
                         R[6],
                         store_cb_data,
                         nullptr);
                store_cb(buf_out,
                         offset_out + tid_hor * stride0_out + (((thread + 0 + 16) / 32) * 128 + (thread + 0 + 16) % 32 + 96) * stride_store_out,
                         R[7],
                         store_cb_data,
                         nullptr);
            }
        }
    }

    else
    {

        // handle post_procession SBRC_3D_FFT_ERC_TRANS_Z_XY in lds after transform
        if (sbrc_type == SBRC_3D_FFT_ERC_TRANS_Z_XY)
        {
            __syncthreads();

            post_process_interleaved_inplace<scalar_type, true, CallbackType::NONE>(
                threadIdx.x,
                128 - threadIdx.x,
                128,
                64,
                lds_complex + 0 * stride_lds,
                0,
                twiddles + 120,
                nullptr,
                nullptr,
                0,
                nullptr,
                nullptr);
            post_process_interleaved_inplace<scalar_type, true, CallbackType::NONE>(
                threadIdx.x,
                128 - threadIdx.x,
                128,
                64,
                lds_complex + 1 * stride_lds,
                0,
                twiddles + 120,
                nullptr,
                nullptr,
                0,
                nullptr,
                nullptr);
            post_process_interleaved_inplace<scalar_type, true, CallbackType::NONE>(
                threadIdx.x,
                128 - threadIdx.x,
                128,
                64,
                lds_complex + 2 * stride_lds,
                0,
                twiddles + 120,
                nullptr,
                nullptr,
                0,
                nullptr,
                nullptr);
            post_process_interleaved_inplace<scalar_type, true, CallbackType::NONE>(
                threadIdx.x,
                128 - threadIdx.x,
                128,
                64,
                lds_complex + 3 * stride_lds,
                0,
                twiddles + 120,
                nullptr,
                nullptr,
                0,
                nullptr,
                nullptr);
            post_process_interleaved_inplace<scalar_type, true, CallbackType::NONE>(
                threadIdx.x,
                128 - threadIdx.x,
                128,
                64,
                lds_complex + 4 * stride_lds,
                0,
                twiddles + 120,
                nullptr,
                nullptr,
                0,
                nullptr,
                nullptr);
            post_process_interleaved_inplace<scalar_type, true, CallbackType::NONE>(
                threadIdx.x,
                128 - threadIdx.x,
                128,
                64,
                lds_complex + 5 * stride_lds,
                0,
                twiddles + 120,
                nullptr,
                nullptr,
                0,
                nullptr,
                nullptr);
            post_process_interleaved_inplace<scalar_type, true, CallbackType::NONE>(
                threadIdx.x,
                128 - threadIdx.x,
                128,
                64,
                lds_complex + 6 * stride_lds,
                0,
                twiddles + 120,
                nullptr,
                nullptr,
                0,
                nullptr,
                nullptr);
            post_process_interleaved_inplace<scalar_type, true, CallbackType::NONE>(
                threadIdx.x,
                128 - threadIdx.x,
                128,
                64,
                lds_complex + 7 * stride_lds,
                0,
                twiddles + 120,
                nullptr,
                nullptr,
                0,
                nullptr,
                nullptr);
        }

        // store global
        __syncthreads();
        thread = threadIdx.x / 8;
        tid_hor = threadIdx.x % 8;
        if (transpose_type != TILE_UNALIGNED || !edge)
        {
            // TODO: Here
            tx = offset_out + (tid_hor * stride0_out + (thread + 0) * stride_store_out);
            blue_data.transform_index = tx;
            bluestein_store_mul_chirp_out(buf_out, tx, lds_complex[tid_hor * stride_lds + (thread + 0) * 1], &blue_data, nullptr);

            tx = offset_out + (tid_hor * stride0_out + (thread + 16) * stride_store_out);
            blue_data.transform_index = tx;
            bluestein_store_mul_chirp_out(buf_out, tx, lds_complex[tid_hor * stride_lds + (thread + 16) * 1], &blue_data, nullptr);

            tx = offset_out + (tid_hor * stride0_out + (thread + 32) * stride_store_out);
            blue_data.transform_index = tx;
            bluestein_store_mul_chirp_out(buf_out, tx, lds_complex[tid_hor * stride_lds + (thread + 32) * 1], &blue_data, nullptr);

            tx = offset_out + (tid_hor * stride0_out + (thread + 48) * stride_store_out);
            blue_data.transform_index = tx;
            bluestein_store_mul_chirp_out(buf_out, tx, lds_complex[tid_hor * stride_lds + (thread + 48) * 1], &blue_data, nullptr);

            tx = offset_out + (tid_hor * stride0_out + (thread + 64) * stride_store_out);
            blue_data.transform_index = tx;
            bluestein_store_mul_chirp_out(buf_out, tx, lds_complex[tid_hor * stride_lds + (thread + 64) * 1], &blue_data, nullptr);

            tx = offset_out + (tid_hor * stride0_out + (thread + 80) * stride_store_out);
            blue_data.transform_index = tx;
            bluestein_store_mul_chirp_out(buf_out, tx, lds_complex[tid_hor * stride_lds + (thread + 80) * 1], &blue_data, nullptr);

            tx = offset_out + (tid_hor * stride0_out + (thread + 96) * stride_store_out);
            blue_data.transform_index = tx;
            bluestein_store_mul_chirp_out(buf_out, tx, lds_complex[tid_hor * stride_lds + (thread + 96) * 1], &blue_data, nullptr);

            tx = offset_out + (tid_hor * stride0_out + (thread + 112) * stride_store_out);
            blue_data.transform_index = tx;
            bluestein_store_mul_chirp_out(buf_out, tx, lds_complex[tid_hor * stride_lds + (thread + 112) * 1], &blue_data, nullptr);

            if (sbrc_type == SBRC_3D_FFT_ERC_TRANS_Z_XY)
            {
                // extra global write for SBRC_3D_FFT_ERC_TRANS_Z_XY
                if (threadIdx.x < 8)
                {
                    store_cb(buf_out,
                             offset_out + (tid_hor * stride0_out + (thread + 128) * stride_store_out),
                             lds_complex[tid_hor * stride_lds + (thread + 128) * 1],
                             store_cb_data,
                             nullptr);
                }
            }
        }

        else
        {
            if (tile_index_in_plane * 8 + tid_hor < len_along_block)
            {
                store_cb(buf_out,
                         offset_out + (tid_hor * stride0_out + (thread + 0) * stride_store_out),
                         lds_complex[tid_hor * stride_lds + (thread + 0) * 1],
                         store_cb_data,
                         nullptr);
                store_cb(buf_out,
                         offset_out + (tid_hor * stride0_out + (thread + 16) * stride_store_out),
                         lds_complex[tid_hor * stride_lds + (thread + 16) * 1],
                         store_cb_data,
                         nullptr);
                store_cb(buf_out,
                         offset_out + (tid_hor * stride0_out + (thread + 32) * stride_store_out),
                         lds_complex[tid_hor * stride_lds + (thread + 32) * 1],
                         store_cb_data,
                         nullptr);
                store_cb(buf_out,
                         offset_out + (tid_hor * stride0_out + (thread + 48) * stride_store_out),
                         lds_complex[tid_hor * stride_lds + (thread + 48) * 1],
                         store_cb_data,
                         nullptr);
                store_cb(buf_out,
                         offset_out + (tid_hor * stride0_out + (thread + 64) * stride_store_out),
                         lds_complex[tid_hor * stride_lds + (thread + 64) * 1],
                         store_cb_data,
                         nullptr);
                store_cb(buf_out,
                         offset_out + (tid_hor * stride0_out + (thread + 80) * stride_store_out),
                         lds_complex[tid_hor * stride_lds + (thread + 80) * 1],
                         store_cb_data,
                         nullptr);
                store_cb(buf_out,
                         offset_out + (tid_hor * stride0_out + (thread + 96) * stride_store_out),
                         lds_complex[tid_hor * stride_lds + (thread + 96) * 1],
                         store_cb_data,
                         nullptr);
                store_cb(buf_out,
                         offset_out + (tid_hor * stride0_out + (thread + 112) * stride_store_out),
                         lds_complex[tid_hor * stride_lds + (thread + 112) * 1],
                         store_cb_data,
                         nullptr);
                if (sbrc_type == SBRC_3D_FFT_ERC_TRANS_Z_XY)
                {
                    // extra global write for SBRC_3D_FFT_ERC_TRANS_Z_XY
                    if (threadIdx.x < (len_along_block % 8))
                    {
                        store_cb(buf_out,
                                 offset_out + (tid_hor * stride0_out + (thread + 128) * stride_store_out),
                                 lds_complex[tid_hor * stride_lds + 128],
                                 store_cb_data,
                                 nullptr);
                    }
                }
            }
        }
    }
}

#endif