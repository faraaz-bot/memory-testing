#ifndef BLUESTEIN_H
#define BLUESTEIN_H

#include <hip/hip_vector_types.h>

#include "../rocfft/common.h"
#include "../rocfft/callback.h"

static constexpr double PI = 3.141592653589793238462643383279;

enum BluesteinBufferAccessMode
{
    ALL,
    FIRST_HALF,
    SECOND_HALF
};

template <typename T>
struct BluesteinData
{
    T *buf_tmp;
    const T *buf_chirp;
    BluesteinBufferAccessMode access_mode;
    size_t length_M;
    size_t length_N;
    size_t transform_index;
};

template <typename scalar_type>
__device__ scalar_type
bluestein_load_chirp_pad(scalar_type *data, size_t offset, BluesteinData<scalar_type> *blueData, void *sharedMem)
{
    if (blueData->transform_index < blueData->length_N)
    {
        return blueData->buf_chirp[blueData->transform_index];
    }
    else if (blueData->transform_index >= blueData->length_M - blueData->length_N)
    {
        return blueData->buf_chirp[blueData->transform_index - blueData->length_M + blueData->length_N];
    }
    else
    {
        return lib_make_vector2<scalar_type>(0, 0);
    }
}

template <typename scalar_type>
__device__ scalar_type bluestein_load_mul_in_chirp_pad(scalar_type *data,
                                                       size_t offset,
                                                       BluesteinData<scalar_type> *blueData,
                                                       void *sharedMem)
{
    if (blueData->transform_index >= blueData->length_N)
    {
        return lib_make_vector2<scalar_type>(0, 0);
    }
    else
    {
        auto elem_scalar = data[offset];
        auto aux_real = elem_scalar.x;

        elem_scalar.x = elem_scalar.x * blueData->buf_chirp[blueData->transform_index].x + elem_scalar.y * blueData->buf_chirp[blueData->transform_index].y;
        elem_scalar.y = -aux_real * blueData->buf_chirp[blueData->transform_index].y + elem_scalar.y * blueData->buf_chirp[blueData->transform_index].x;

        return elem_scalar;
    }
}

template <typename scalar_type>
__device__ scalar_type
bluestein_load_tmp(scalar_type *data, size_t offset, BluesteinData<scalar_type> *blueData, void *sharedMem)
{
    if (blueData->access_mode == BluesteinBufferAccessMode::ALL)
    {
        return blueData->buf_tmp[blueData->transform_index];
    }
    else if (blueData->access_mode == BluesteinBufferAccessMode::FIRST_HALF)
    {
        return blueData->transform_index < blueData->length_M ? blueData->buf_tmp[blueData->transform_index]
                                                              : lib_make_vector2<scalar_type>(0, 0);
    }
    else if (blueData->access_mode == BluesteinBufferAccessMode::SECOND_HALF)
    {
        return blueData->buf_tmp[blueData->transform_index + blueData->length_M];
    }

    return lib_make_vector2<scalar_type>(0, 0);
}

template <typename scalar_type>
__device__ scalar_type
bluestein_load_mul_tmp(scalar_type *data, size_t offset, BluesteinData<scalar_type> *blueData, void *sharedMem)
{
    auto elem_scalar = blueData->buf_tmp[blueData->transform_index];
    auto aux_scalar = blueData->buf_tmp[blueData->transform_index + blueData->length_M];
    auto aux_real = elem_scalar.x;
    elem_scalar.x = elem_scalar.x * aux_scalar.x - elem_scalar.y * aux_scalar.y;
    elem_scalar.y = aux_real * aux_scalar.y + elem_scalar.y * aux_scalar.x;

    return elem_scalar;
}

template <typename scalar_type>
__device__ void bluestein_store_tmp(
    scalar_type *data, size_t offset, scalar_type element, BluesteinData<scalar_type> *blueData, void *sharedMem)
{
    if (blueData->access_mode == BluesteinBufferAccessMode::ALL)
    {
        blueData->buf_tmp[blueData->transform_index] = element;
    }
    else if (blueData->access_mode == BluesteinBufferAccessMode::FIRST_HALF)
    {
        blueData->buf_tmp[blueData->transform_index] = element;
    }
    else if (blueData->access_mode == BluesteinBufferAccessMode::SECOND_HALF)
    {
        blueData->buf_tmp[blueData->transform_index + blueData->length_M] = element;
    }
}

template <typename scalar_type>
__device__ void bluestein_store_mul_chirp_out(
    scalar_type *data, size_t offset, scalar_type element, BluesteinData<scalar_type> *blueData, void *sharedMem)
{
    if (blueData->transform_index < blueData->length_N)
    {
        element *= (1. / ((real_type_t<scalar_type>)blueData->length_M));

        auto aux_real = element.x;
        element.x = element.x * blueData->buf_chirp[blueData->transform_index].x + element.y * blueData->buf_chirp[blueData->transform_index].y;
        element.y = -aux_real * blueData->buf_chirp[blueData->transform_index].y + element.y * blueData->buf_chirp[blueData->transform_index].x;

        data[offset] = element;
    }
}

#endif