#ifndef BLUESTEIN_64_SBCC_MUL_CHIRP_H
#define BLUESTEIN_64_SBCC_MUL_CHIRP_H

#include "bluestein.h"
#include "../rocfft/butterfly_constant.h"
#include "../rocfft/common.h"
#include "../rocfft/real2complex_device.h"
#include "../rocfft/rocfft_butterfly_template.h"
#include <hip/hip_runtime.h>

template <typename scalar_type, StrideBin sb>
__device__ void lds_to_reg_input_length64_mul_chirp_device(scalar_type *R,
                                                           scalar_type *__restrict__ lds_complex,
                                                           unsigned int stride_lds,
                                                           unsigned int offset_lds,
                                                           unsigned int thread,
                                                           bool write)
{
    const unsigned int lstride = (sb == SB_UNIT) ? (1) : (stride_lds);
    unsigned int l_offset;
    __syncthreads();
    l_offset = offset_lds + ((thread + 0 + 0) + 0) * lstride;
    R[0] = lds_complex[l_offset];
    l_offset = offset_lds + ((thread + 0 + 0) + 8) * lstride;
    R[1] = lds_complex[l_offset];
    l_offset = offset_lds + ((thread + 0 + 0) + 16) * lstride;
    R[2] = lds_complex[l_offset];
    l_offset = offset_lds + ((thread + 0 + 0) + 24) * lstride;
    R[3] = lds_complex[l_offset];
    l_offset = offset_lds + ((thread + 0 + 0) + 32) * lstride;
    R[4] = lds_complex[l_offset];
    l_offset = offset_lds + ((thread + 0 + 0) + 40) * lstride;
    R[5] = lds_complex[l_offset];
    l_offset = offset_lds + ((thread + 0 + 0) + 48) * lstride;
    R[6] = lds_complex[l_offset];
    l_offset = offset_lds + ((thread + 0 + 0) + 56) * lstride;
    R[7] = lds_complex[l_offset];
}
template <typename scalar_type, StrideBin sb>
__device__ void lds_from_reg_output_length64_mul_chirp_device(scalar_type *R,
                                                              scalar_type *__restrict__ lds_complex,
                                                              unsigned int stride_lds,
                                                              unsigned int offset_lds,
                                                              unsigned int thread,
                                                              bool write)
{
    const unsigned int lstride = (sb == SB_UNIT) ? (1) : (stride_lds);
    unsigned int l_offset;
    __syncthreads();
    l_offset = offset_lds + (((thread + 0 + 0) / 8) * 64 + (thread + 0 + 0) % 8 + 0) * lstride;
    lds_complex[l_offset] = R[0];
    l_offset = offset_lds + (((thread + 0 + 0) / 8) * 64 + (thread + 0 + 0) % 8 + 8) * lstride;
    lds_complex[l_offset] = R[1];
    l_offset = offset_lds + (((thread + 0 + 0) / 8) * 64 + (thread + 0 + 0) % 8 + 16) * lstride;
    lds_complex[l_offset] = R[2];
    l_offset = offset_lds + (((thread + 0 + 0) / 8) * 64 + (thread + 0 + 0) % 8 + 24) * lstride;
    lds_complex[l_offset] = R[3];
    l_offset = offset_lds + (((thread + 0 + 0) / 8) * 64 + (thread + 0 + 0) % 8 + 32) * lstride;
    lds_complex[l_offset] = R[4];
    l_offset = offset_lds + (((thread + 0 + 0) / 8) * 64 + (thread + 0 + 0) % 8 + 40) * lstride;
    lds_complex[l_offset] = R[5];
    l_offset = offset_lds + (((thread + 0 + 0) / 8) * 64 + (thread + 0 + 0) % 8 + 48) * lstride;
    lds_complex[l_offset] = R[6];
    l_offset = offset_lds + (((thread + 0 + 0) / 8) * 64 + (thread + 0 + 0) % 8 + 56) * lstride;
    lds_complex[l_offset] = R[7];
}
template <typename scalar_type,
          const bool lds_is_real,
          StrideBin sb,
          const bool lds_linear,
          const bool direct_load_to_reg,
          bool apply_large_twiddle,
          size_t large_twiddle_steps = 2,
          size_t large_twiddle_base = 8>
__device__ void inverse_length64_SBCC_mul_chirp_device(scalar_type *R,
                                                       real_type_t<scalar_type> *__restrict__ lds_real,
                                                       scalar_type *__restrict__ lds_complex,
                                                       const scalar_type *__restrict__ twiddles,
                                                       unsigned int stride_lds,
                                                       unsigned int offset_lds,
                                                       unsigned int thread,
                                                       bool write,
                                                       const scalar_type *large_twiddles,
                                                       size_t trans_local)
{
    scalar_type W;
    scalar_type t;
    const unsigned int lstride = (sb == SB_UNIT) ? (1) : (stride_lds);
    unsigned int l_offset;

    // pass 0, width 8
    // using 8 threads we need to do 8 radix-8 butterflies
    // therefore each thread will do 1.000000 butterflies
    InvRad8B1(R + 0, R + 1, R + 2, R + 3, R + 4, R + 5, R + 6, R + 7);
    if (!lds_is_real)
    {
        if (!direct_load_to_reg)
        {
            __syncthreads();
        }

        l_offset = offset_lds + (((thread + 0 + 0) / 1) * 8 + (thread + 0 + 0) % 1 + 0) * lstride;
        lds_complex[l_offset] = R[0];
        l_offset = offset_lds + (((thread + 0 + 0) / 1) * 8 + (thread + 0 + 0) % 1 + 1) * lstride;
        lds_complex[l_offset] = R[1];
        l_offset = offset_lds + (((thread + 0 + 0) / 1) * 8 + (thread + 0 + 0) % 1 + 2) * lstride;
        lds_complex[l_offset] = R[2];
        l_offset = offset_lds + (((thread + 0 + 0) / 1) * 8 + (thread + 0 + 0) % 1 + 3) * lstride;
        lds_complex[l_offset] = R[3];
        l_offset = offset_lds + (((thread + 0 + 0) / 1) * 8 + (thread + 0 + 0) % 1 + 4) * lstride;
        lds_complex[l_offset] = R[4];
        l_offset = offset_lds + (((thread + 0 + 0) / 1) * 8 + (thread + 0 + 0) % 1 + 5) * lstride;
        lds_complex[l_offset] = R[5];
        l_offset = offset_lds + (((thread + 0 + 0) / 1) * 8 + (thread + 0 + 0) % 1 + 6) * lstride;
        lds_complex[l_offset] = R[6];
        l_offset = offset_lds + (((thread + 0 + 0) / 1) * 8 + (thread + 0 + 0) % 1 + 7) * lstride;
        lds_complex[l_offset] = R[7];
    }

    else
    {
        l_offset = offset_lds + (((thread + 0 + 0) / 1) * 8 + (thread + 0 + 0) % 1 + 0) * lstride;
        lds_real[l_offset] = R[0].x;
        l_offset = offset_lds + (((thread + 0 + 0) / 1) * 8 + (thread + 0 + 0) % 1 + 1) * lstride;
        lds_real[l_offset] = R[1].x;
        l_offset = offset_lds + (((thread + 0 + 0) / 1) * 8 + (thread + 0 + 0) % 1 + 2) * lstride;
        lds_real[l_offset] = R[2].x;
        l_offset = offset_lds + (((thread + 0 + 0) / 1) * 8 + (thread + 0 + 0) % 1 + 3) * lstride;
        lds_real[l_offset] = R[3].x;
        l_offset = offset_lds + (((thread + 0 + 0) / 1) * 8 + (thread + 0 + 0) % 1 + 4) * lstride;
        lds_real[l_offset] = R[4].x;
        l_offset = offset_lds + (((thread + 0 + 0) / 1) * 8 + (thread + 0 + 0) % 1 + 5) * lstride;
        lds_real[l_offset] = R[5].x;
        l_offset = offset_lds + (((thread + 0 + 0) / 1) * 8 + (thread + 0 + 0) % 1 + 6) * lstride;
        lds_real[l_offset] = R[6].x;
        l_offset = offset_lds + (((thread + 0 + 0) / 1) * 8 + (thread + 0 + 0) % 1 + 7) * lstride;
        lds_real[l_offset] = R[7].x;
        __syncthreads();
        l_offset = offset_lds + ((thread + 0 + 0) + 0) * lstride;
        R[0].x = lds_real[l_offset];
        l_offset = offset_lds + ((thread + 0 + 0) + 8) * lstride;
        R[1].x = lds_real[l_offset];
        l_offset = offset_lds + ((thread + 0 + 0) + 16) * lstride;
        R[2].x = lds_real[l_offset];
        l_offset = offset_lds + ((thread + 0 + 0) + 24) * lstride;
        R[3].x = lds_real[l_offset];
        l_offset = offset_lds + ((thread + 0 + 0) + 32) * lstride;
        R[4].x = lds_real[l_offset];
        l_offset = offset_lds + ((thread + 0 + 0) + 40) * lstride;
        R[5].x = lds_real[l_offset];
        l_offset = offset_lds + ((thread + 0 + 0) + 48) * lstride;
        R[6].x = lds_real[l_offset];
        l_offset = offset_lds + ((thread + 0 + 0) + 56) * lstride;
        R[7].x = lds_real[l_offset];
        __syncthreads();
        l_offset = offset_lds + (((thread + 0 + 0) / 1) * 8 + (thread + 0 + 0) % 1 + 0) * lstride;
        lds_real[l_offset] = R[0].y;
        l_offset = offset_lds + (((thread + 0 + 0) / 1) * 8 + (thread + 0 + 0) % 1 + 1) * lstride;
        lds_real[l_offset] = R[1].y;
        l_offset = offset_lds + (((thread + 0 + 0) / 1) * 8 + (thread + 0 + 0) % 1 + 2) * lstride;
        lds_real[l_offset] = R[2].y;
        l_offset = offset_lds + (((thread + 0 + 0) / 1) * 8 + (thread + 0 + 0) % 1 + 3) * lstride;
        lds_real[l_offset] = R[3].y;
        l_offset = offset_lds + (((thread + 0 + 0) / 1) * 8 + (thread + 0 + 0) % 1 + 4) * lstride;
        lds_real[l_offset] = R[4].y;
        l_offset = offset_lds + (((thread + 0 + 0) / 1) * 8 + (thread + 0 + 0) % 1 + 5) * lstride;
        lds_real[l_offset] = R[5].y;
        l_offset = offset_lds + (((thread + 0 + 0) / 1) * 8 + (thread + 0 + 0) % 1 + 6) * lstride;
        lds_real[l_offset] = R[6].y;
        l_offset = offset_lds + (((thread + 0 + 0) / 1) * 8 + (thread + 0 + 0) % 1 + 7) * lstride;
        lds_real[l_offset] = R[7].y;
        __syncthreads();
        l_offset = offset_lds + ((thread + 0 + 0) + 0) * lstride;
        R[0].y = lds_real[l_offset];
        l_offset = offset_lds + ((thread + 0 + 0) + 8) * lstride;
        R[1].y = lds_real[l_offset];
        l_offset = offset_lds + ((thread + 0 + 0) + 16) * lstride;
        R[2].y = lds_real[l_offset];
        l_offset = offset_lds + ((thread + 0 + 0) + 24) * lstride;
        R[3].y = lds_real[l_offset];
        l_offset = offset_lds + ((thread + 0 + 0) + 32) * lstride;
        R[4].y = lds_real[l_offset];
        l_offset = offset_lds + ((thread + 0 + 0) + 40) * lstride;
        R[5].y = lds_real[l_offset];
        l_offset = offset_lds + ((thread + 0 + 0) + 48) * lstride;
        R[6].y = lds_real[l_offset];
        l_offset = offset_lds + ((thread + 0 + 0) + 56) * lstride;
        R[7].y = lds_real[l_offset];
    }

    // pass 1, width 8
    // using 8 threads we need to do 8 radix-8 butterflies
    // therefore each thread will do 1.000000 butterflies
    if (!lds_is_real)
    {
        __syncthreads();
        l_offset = offset_lds + ((thread + 0 + 0) + 0) * lstride;
        R[0] = lds_complex[l_offset];
        l_offset = offset_lds + ((thread + 0 + 0) + 8) * lstride;
        R[1] = lds_complex[l_offset];
        l_offset = offset_lds + ((thread + 0 + 0) + 16) * lstride;
        R[2] = lds_complex[l_offset];
        l_offset = offset_lds + ((thread + 0 + 0) + 24) * lstride;
        R[3] = lds_complex[l_offset];
        l_offset = offset_lds + ((thread + 0 + 0) + 32) * lstride;
        R[4] = lds_complex[l_offset];
        l_offset = offset_lds + ((thread + 0 + 0) + 40) * lstride;
        R[5] = lds_complex[l_offset];
        l_offset = offset_lds + ((thread + 0 + 0) + 48) * lstride;
        R[6] = lds_complex[l_offset];
        l_offset = offset_lds + ((thread + 0 + 0) + 56) * lstride;
        R[7] = lds_complex[l_offset];
    }

    W = twiddles[0 + 7 * ((thread + 0 + 0) % 8)];
    t = {R[1].x * W.x + R[1].y * W.y, R[1].y * W.x - R[1].x * W.y};
    R[1] = t;
    W = twiddles[1 + 7 * ((thread + 0 + 0) % 8)];
    t = {R[2].x * W.x + R[2].y * W.y, R[2].y * W.x - R[2].x * W.y};
    R[2] = t;
    W = twiddles[2 + 7 * ((thread + 0 + 0) % 8)];
    t = {R[3].x * W.x + R[3].y * W.y, R[3].y * W.x - R[3].x * W.y};
    R[3] = t;
    W = twiddles[3 + 7 * ((thread + 0 + 0) % 8)];
    t = {R[4].x * W.x + R[4].y * W.y, R[4].y * W.x - R[4].x * W.y};
    R[4] = t;
    W = twiddles[4 + 7 * ((thread + 0 + 0) % 8)];
    t = {R[5].x * W.x + R[5].y * W.y, R[5].y * W.x - R[5].x * W.y};
    R[5] = t;
    W = twiddles[5 + 7 * ((thread + 0 + 0) % 8)];
    t = {R[6].x * W.x + R[6].y * W.y, R[6].y * W.x - R[6].x * W.y};
    R[6] = t;
    W = twiddles[6 + 7 * ((thread + 0 + 0) % 8)];
    t = {R[7].x * W.x + R[7].y * W.y, R[7].y * W.x - R[7].x * W.y};
    R[7] = t;
    InvRad8B1(R + 0, R + 1, R + 2, R + 3, R + 4, R + 5, R + 6, R + 7);
    if (apply_large_twiddle)
    {
        // large twiddle multiplication
        W = TW_NSteps<scalar_type, large_twiddle_base, large_twiddle_steps>(
            large_twiddles, (((int)(thread + 0 + 0) % 8) + 0 * 8) * trans_local);
        t = {R[0].x * W.x + R[0].y * W.y, R[0].y * W.x - R[0].x * W.y};
        R[0] = t;
        W = TW_NSteps<scalar_type, large_twiddle_base, large_twiddle_steps>(
            large_twiddles, (((int)(thread + 0 + 0) % 8) + 1 * 8) * trans_local);
        t = {R[1].x * W.x + R[1].y * W.y, R[1].y * W.x - R[1].x * W.y};
        R[1] = t;
        W = TW_NSteps<scalar_type, large_twiddle_base, large_twiddle_steps>(
            large_twiddles, (((int)(thread + 0 + 0) % 8) + 2 * 8) * trans_local);
        t = {R[2].x * W.x + R[2].y * W.y, R[2].y * W.x - R[2].x * W.y};
        R[2] = t;
        W = TW_NSteps<scalar_type, large_twiddle_base, large_twiddle_steps>(
            large_twiddles, (((int)(thread + 0 + 0) % 8) + 3 * 8) * trans_local);
        t = {R[3].x * W.x + R[3].y * W.y, R[3].y * W.x - R[3].x * W.y};
        R[3] = t;
        W = TW_NSteps<scalar_type, large_twiddle_base, large_twiddle_steps>(
            large_twiddles, (((int)(thread + 0 + 0) % 8) + 4 * 8) * trans_local);
        t = {R[4].x * W.x + R[4].y * W.y, R[4].y * W.x - R[4].x * W.y};
        R[4] = t;
        W = TW_NSteps<scalar_type, large_twiddle_base, large_twiddle_steps>(
            large_twiddles, (((int)(thread + 0 + 0) % 8) + 5 * 8) * trans_local);
        t = {R[5].x * W.x + R[5].y * W.y, R[5].y * W.x - R[5].x * W.y};
        R[5] = t;
        W = TW_NSteps<scalar_type, large_twiddle_base, large_twiddle_steps>(
            large_twiddles, (((int)(thread + 0 + 0) % 8) + 6 * 8) * trans_local);
        t = {R[6].x * W.x + R[6].y * W.y, R[6].y * W.x - R[6].x * W.y};
        R[6] = t;
        W = TW_NSteps<scalar_type, large_twiddle_base, large_twiddle_steps>(
            large_twiddles, (((int)(thread + 0 + 0) % 8) + 7 * 8) * trans_local);
        t = {R[7].x * W.x + R[7].y * W.y, R[7].y * W.x - R[7].x * W.y};
        R[7] = t;
    }
}
template <typename scalar_type,
          size_t large_twiddle_steps = 2,
          size_t large_twiddle_base = 8>
__global__
    __launch_bounds__(256) void op_inverse_length64_SBCC_mul_chirp(const scalar_type *__restrict__ twiddles,
                                                                   const scalar_type *large_twiddles,
                                                                   const size_t dim,
                                                                   const size_t N,
                                                                   const size_t *__restrict__ lengths,
                                                                   const size_t *__restrict__ stride_in,
                                                                   const size_t *__restrict__ stride_out,
                                                                   const size_t nbatch,
                                                                   const unsigned int lds_padding,
                                                                   void *__restrict__ load_cb_fn,
                                                                   void *__restrict__ load_cb_data,
                                                                   unsigned int load_cb_lds_bytes,
                                                                   void *__restrict__ store_cb_fn,
                                                                   void *__restrict__ store_cb_data,
                                                                   scalar_type *__restrict__ buf_in,
                                                                   scalar_type *__restrict__ buf_out,
                                                                   const scalar_type *__restrict__ chirp_buf,
                                                                   scalar_type *__restrict__ buf_tmp)
{
    auto const sb = StrideBin::SB_NONUNIT;
    auto const ebtype = EmbeddedType::NONE;
    auto const drtype = DirectRegType::TRY_ENABLE_IF_SUPPORT;
    auto const intrinsic_mode = IntrinsicAccessType::ENABLE_BOTH;
    auto const apply_large_twiddle = true;

    // this kernel:
    //   uses 8 threads per transform
    //   does 32 transforms per thread block
    // therefore it should be called with 256 threads per thread block
    scalar_type R[8];
    extern __shared__ unsigned char __attribute__((aligned(sizeof(scalar_type)))) lds_uchar[];
    real_type_t<scalar_type> *__restrict__ lds_real = reinterpret_cast<real_type_t<scalar_type> *>(lds_uchar);
    scalar_type *__restrict__ lds_complex = reinterpret_cast<scalar_type *>(lds_uchar);
    size_t offset_in = 0;
    size_t offset_out = 0;
    unsigned int offset_lds;
    unsigned int stride_lds;
    size_t batch;
    size_t transform;
    const bool direct_load_to_reg = drtype == DirectRegType::TRY_ENABLE_IF_SUPPORT;
    const bool direct_store_from_reg = direct_load_to_reg;
    const bool lds_linear = !direct_load_to_reg;
    const bool lds_is_real = false;
    auto load_cb = get_load_cb<scalar_type, CallbackType::NONE>(load_cb_fn);
    auto store_cb = get_store_cb<scalar_type, CallbackType::NONE>(store_cb_fn);

    // large twiddles
    __shared__ scalar_type large_twd_lds[(apply_large_twiddle && large_twiddle_base < 8)
                                             ? ((1 << large_twiddle_base) * 3)
                                             : (0)];
    if (apply_large_twiddle && large_twiddle_base < 8)
    {
        size_t ltwd_id = threadIdx.x;
        while (ltwd_id < (1 << large_twiddle_base) * 3)
        {
            large_twd_lds[ltwd_id] = large_twiddles[ltwd_id];
            ltwd_id += 256;
        }
    }

    // offsets
    const size_t stride0_in = (sb == SB_UNIT) ? (1) : (stride_in[0]);
    const size_t stride0_out = (sb == SB_UNIT) ? (1) : (stride_out[0]);
    size_t tile_index;
    size_t num_of_tiles;

    // calculate offset for each tile:
    //   tile_index  now means index of the tile along dim1
    //   num_of_tiles now means number of tiles along dim1
    size_t plength = 1;
    size_t remaining;
    size_t index_along_d;
    num_of_tiles = (lengths[1] - 1) / 32 + 1;
    plength = num_of_tiles;
    tile_index = blockIdx.x % num_of_tiles;
    remaining = blockIdx.x / num_of_tiles;
    offset_in = tile_index * 32 * stride_in[1];
    offset_out = tile_index * 32 * stride_out[1];
    for (int d = 2; d < dim; ++d)
    {
        plength = plength * lengths[d];
        index_along_d = remaining % lengths[d];
        remaining = remaining / lengths[d];
        offset_in = offset_in + index_along_d * stride_in[d];
        offset_out = offset_out + index_along_d * stride_out[d];
    }

    batch = blockIdx.x / plength;
    offset_in = offset_in + batch * stride_in[dim];
    offset_out = offset_out + batch * stride_out[dim];
    transform = lds_linear ? tile_index * 32 + threadIdx.x / 8 : tile_index * 32 + threadIdx.x % 32;
    stride_lds = lds_linear ? 64 + (ebtype == EmbeddedType::NONE ? 0 : lds_padding)
                            : 32 + (ebtype == EmbeddedType::NONE ? 0 : lds_padding);
    offset_lds = lds_linear ? stride_lds * (transform % 32) : threadIdx.x % 32;
    bool in_bound = ((tile_index + 1) * 32 > lengths[1]) ? false : true;
    unsigned int thread = threadIdx.x / 32;
    unsigned int tid_hor = threadIdx.x % 32;

    scalar_type aux_scalar;
    real_type_t<scalar_type> aux_real;
    size_t M = 1;
    size_t tx;
    for (int d = 0; d < dim; ++d)
    {
        M *= lengths[d];
    }
    BluesteinData<scalar_type> blue_data;
    blue_data.length_M = M;
    blue_data.length_N = N;
    blue_data.buf_chirp = chirp_buf;
    blue_data.buf_tmp = buf_tmp;
    blue_data.access_mode = BluesteinBufferAccessMode::ALL;

    if (direct_load_to_reg)
    {
        // load global into registers
        if (intrinsic_mode != IntrinsicAccessType::DISABLE_BOTH)
        {
            // TODO: Here
            tx = offset_in + tid_hor * stride_in[1] + (((thread + 0 + 0) + 0)) * stride0_in;
            blue_data.transform_index = tx;
            R[0] = bluestein_load_mul_tmp(buf_in, tx, &blue_data, nullptr);

            tx = offset_in + tid_hor * stride_in[1] + (((thread + 0 + 0) + 8)) * stride0_in;
            blue_data.transform_index = tx;
            R[1] = bluestein_load_mul_tmp(buf_in, tx, &blue_data, nullptr);

            tx = offset_in + tid_hor * stride_in[1] + (((thread + 0 + 0) + 16)) * stride0_in;
            blue_data.transform_index = tx;
            R[2] = bluestein_load_mul_tmp(buf_in, tx, &blue_data, nullptr);

            tx = offset_in + tid_hor * stride_in[1] + (((thread + 0 + 0) + 24)) * stride0_in;
            blue_data.transform_index = tx;
            R[3] = bluestein_load_mul_tmp(buf_in, tx, &blue_data, nullptr);

            tx = offset_in + tid_hor * stride_in[1] + (((thread + 0 + 0) + 32)) * stride0_in;
            blue_data.transform_index = tx;
            R[4] = bluestein_load_mul_tmp(buf_in, tx, &blue_data, nullptr);

            tx = offset_in + tid_hor * stride_in[1] + (((thread + 0 + 0) + 40)) * stride0_in;
            blue_data.transform_index = tx;
            R[5] = bluestein_load_mul_tmp(buf_in, tx, &blue_data, nullptr);

            tx = offset_in + tid_hor * stride_in[1] + (((thread + 0 + 0) + 48)) * stride0_in;
            blue_data.transform_index = tx;
            R[6] = bluestein_load_mul_tmp(buf_in, tx, &blue_data, nullptr);

            tx = offset_in + tid_hor * stride_in[1] + (((thread + 0 + 0) + 56)) * stride0_in;
            blue_data.transform_index = tx;
            R[7] = bluestein_load_mul_tmp(buf_in, tx, &blue_data, nullptr);
        }

        else
        {
            // can't use intrinsic load
            if (in_bound)
            {
                R[0] = load_cb(buf_in,
                               offset_in + tid_hor * stride_in[1] + (((thread + 0 + 0) + 0)) * stride0_in,
                               load_cb_data,
                               nullptr);
                R[1] = load_cb(buf_in,
                               offset_in + tid_hor * stride_in[1] + (((thread + 0 + 0) + 8)) * stride0_in,
                               load_cb_data,
                               nullptr);
                R[2] = load_cb(buf_in,
                               offset_in + tid_hor * stride_in[1] + (((thread + 0 + 0) + 16)) * stride0_in,
                               load_cb_data,
                               nullptr);
                R[3] = load_cb(buf_in,
                               offset_in + tid_hor * stride_in[1] + (((thread + 0 + 0) + 24)) * stride0_in,
                               load_cb_data,
                               nullptr);
                R[4] = load_cb(buf_in,
                               offset_in + tid_hor * stride_in[1] + (((thread + 0 + 0) + 32)) * stride0_in,
                               load_cb_data,
                               nullptr);
                R[5] = load_cb(buf_in,
                               offset_in + tid_hor * stride_in[1] + (((thread + 0 + 0) + 40)) * stride0_in,
                               load_cb_data,
                               nullptr);
                R[6] = load_cb(buf_in,
                               offset_in + tid_hor * stride_in[1] + (((thread + 0 + 0) + 48)) * stride0_in,
                               load_cb_data,
                               nullptr);
                R[7] = load_cb(buf_in,
                               offset_in + tid_hor * stride_in[1] + (((thread + 0 + 0) + 56)) * stride0_in,
                               load_cb_data,
                               nullptr);
            }

            if (!in_bound)
            {
                if (tile_index * 32 + tid_hor < lengths[1])
                {
                    R[0] = load_cb(buf_in,
                                   offset_in + tid_hor * stride_in[1] + (((thread + 0 + 0) + 0)) * stride0_in,
                                   load_cb_data,
                                   nullptr);
                    R[1] = load_cb(buf_in,
                                   offset_in + tid_hor * stride_in[1] + (((thread + 0 + 0) + 8)) * stride0_in,
                                   load_cb_data,
                                   nullptr);
                    R[2] = load_cb(buf_in,
                                   offset_in + tid_hor * stride_in[1] + (((thread + 0 + 0) + 16)) * stride0_in,
                                   load_cb_data,
                                   nullptr);
                    R[3] = load_cb(buf_in,
                                   offset_in + tid_hor * stride_in[1] + (((thread + 0 + 0) + 24)) * stride0_in,
                                   load_cb_data,
                                   nullptr);
                    R[4] = load_cb(buf_in,
                                   offset_in + tid_hor * stride_in[1] + (((thread + 0 + 0) + 32)) * stride0_in,
                                   load_cb_data,
                                   nullptr);
                    R[5] = load_cb(buf_in,
                                   offset_in + tid_hor * stride_in[1] + (((thread + 0 + 0) + 40)) * stride0_in,
                                   load_cb_data,
                                   nullptr);
                    R[6] = load_cb(buf_in,
                                   offset_in + tid_hor * stride_in[1] + (((thread + 0 + 0) + 48)) * stride0_in,
                                   load_cb_data,
                                   nullptr);
                    R[7] = load_cb(buf_in,
                                   offset_in + tid_hor * stride_in[1] + (((thread + 0 + 0) + 56)) * stride0_in,
                                   load_cb_data,
                                   nullptr);
                }
            }
        }
    }

    else
    {
        // load global into lds
        // no intrinsic when load to lds. FIXME- check why use nested branch is better
        if (in_bound)
        {
            lds_complex[tid_hor * stride_lds + (thread + 0) * 1] = load_cb(buf_in,
                                                                           offset_in + (tid_hor * stride_in[1] + (thread + 0) * stride0_in),
                                                                           load_cb_data,
                                                                           nullptr);
            lds_complex[tid_hor * stride_lds + (thread + 8) * 1] = load_cb(buf_in,
                                                                           offset_in + (tid_hor * stride_in[1] + (thread + 8) * stride0_in),
                                                                           load_cb_data,
                                                                           nullptr);
            lds_complex[tid_hor * stride_lds + (thread + 16) * 1] = load_cb(buf_in,
                                                                            offset_in + (tid_hor * stride_in[1] + (thread + 16) * stride0_in),
                                                                            load_cb_data,
                                                                            nullptr);
            lds_complex[tid_hor * stride_lds + (thread + 24) * 1] = load_cb(buf_in,
                                                                            offset_in + (tid_hor * stride_in[1] + (thread + 24) * stride0_in),
                                                                            load_cb_data,
                                                                            nullptr);
            lds_complex[tid_hor * stride_lds + (thread + 32) * 1] = load_cb(buf_in,
                                                                            offset_in + (tid_hor * stride_in[1] + (thread + 32) * stride0_in),
                                                                            load_cb_data,
                                                                            nullptr);
            lds_complex[tid_hor * stride_lds + (thread + 40) * 1] = load_cb(buf_in,
                                                                            offset_in + (tid_hor * stride_in[1] + (thread + 40) * stride0_in),
                                                                            load_cb_data,
                                                                            nullptr);
            lds_complex[tid_hor * stride_lds + (thread + 48) * 1] = load_cb(buf_in,
                                                                            offset_in + (tid_hor * stride_in[1] + (thread + 48) * stride0_in),
                                                                            load_cb_data,
                                                                            nullptr);
            lds_complex[tid_hor * stride_lds + (thread + 56) * 1] = load_cb(buf_in,
                                                                            offset_in + (tid_hor * stride_in[1] + (thread + 56) * stride0_in),
                                                                            load_cb_data,
                                                                            nullptr);
        }

        if (!in_bound)
        {
            if (tile_index * 32 + tid_hor < lengths[1])
            {
                lds_complex[tid_hor * stride_lds + (thread + 0) * 1] = load_cb(buf_in,
                                                                               offset_in + (tid_hor * stride_in[1] + (thread + 0) * stride0_in),
                                                                               load_cb_data,
                                                                               nullptr);
                lds_complex[tid_hor * stride_lds + (thread + 8) * 1] = load_cb(buf_in,
                                                                               offset_in + (tid_hor * stride_in[1] + (thread + 8) * stride0_in),
                                                                               load_cb_data,
                                                                               nullptr);
                lds_complex[tid_hor * stride_lds + (thread + 16) * 1] = load_cb(buf_in,
                                                                                offset_in + (tid_hor * stride_in[1] + (thread + 16) * stride0_in),
                                                                                load_cb_data,
                                                                                nullptr);
                lds_complex[tid_hor * stride_lds + (thread + 24) * 1] = load_cb(buf_in,
                                                                                offset_in + (tid_hor * stride_in[1] + (thread + 24) * stride0_in),
                                                                                load_cb_data,
                                                                                nullptr);
                lds_complex[tid_hor * stride_lds + (thread + 32) * 1] = load_cb(buf_in,
                                                                                offset_in + (tid_hor * stride_in[1] + (thread + 32) * stride0_in),
                                                                                load_cb_data,
                                                                                nullptr);
                lds_complex[tid_hor * stride_lds + (thread + 40) * 1] = load_cb(buf_in,
                                                                                offset_in + (tid_hor * stride_in[1] + (thread + 40) * stride0_in),
                                                                                load_cb_data,
                                                                                nullptr);
                lds_complex[tid_hor * stride_lds + (thread + 48) * 1] = load_cb(buf_in,
                                                                                offset_in + (tid_hor * stride_in[1] + (thread + 48) * stride0_in),
                                                                                load_cb_data,
                                                                                nullptr);
                lds_complex[tid_hor * stride_lds + (thread + 56) * 1] = load_cb(buf_in,
                                                                                offset_in + (tid_hor * stride_in[1] + (thread + 56) * stride0_in),
                                                                                load_cb_data,
                                                                                nullptr);
            }
        }
    }

    // calc the thread_in_device value once and for all device funcs
    unsigned int thread_in_device = lds_linear ? threadIdx.x % 8 : threadIdx.x / 32;

    // call a pre-load from lds to registers (if necessary)
    if (!direct_load_to_reg)
    {
        lds_to_reg_input_length64_mul_chirp_device<scalar_type, lds_linear ? SB_UNIT : SB_NONUNIT>(
            R, lds_complex, stride_lds, offset_lds, thread_in_device, true);
    }

    // transform
    inverse_length64_SBCC_mul_chirp_device<scalar_type,
                                           lds_is_real,
                                           lds_linear ? SB_UNIT : SB_NONUNIT,
                                           lds_linear,
                                           direct_load_to_reg,
                                           apply_large_twiddle,
                                           large_twiddle_steps,
                                           large_twiddle_base>(
        R,
        lds_real,
        lds_complex,
        twiddles,
        stride_lds,
        offset_lds,
        thread_in_device,
        true,
        (apply_large_twiddle && large_twiddle_base < 8) ? (large_twd_lds) : (large_twiddles),
        transform);

    // call a post-store from registers to lds (if necessary)
    if (!direct_store_from_reg)
    {
        lds_from_reg_output_length64_mul_chirp_device<scalar_type, lds_linear ? SB_UNIT : SB_NONUNIT>(
            R, lds_complex, stride_lds, offset_lds, thread_in_device, true);
    }

    if (direct_store_from_reg)
    {
        // store registers into global
        if (intrinsic_mode == IntrinsicAccessType::ENABLE_BOTH)
        {
            // TODO: Here
            tx = offset_out + tid_hor * stride_out[1] + (((thread + 0 + 0) / 8) * 64 + (thread + 0 + 0) % 8 + 0) * stride0_out;
            blue_data.transform_index = tx;
            bluestein_store_tmp(buf_out, tx, R[0], &blue_data, nullptr);

            tx = offset_out + tid_hor * stride_out[1] + (((thread + 0 + 0) / 8) * 64 + (thread + 0 + 0) % 8 + 8) * stride0_out;
            blue_data.transform_index = tx;
            bluestein_store_tmp(buf_out, tx, R[1], &blue_data, nullptr);

            tx = offset_out + tid_hor * stride_out[1] + (((thread + 0 + 0) / 8) * 64 + (thread + 0 + 0) % 8 + 16) * stride0_out;
            blue_data.transform_index = tx;
            bluestein_store_tmp(buf_out, tx, R[2], &blue_data, nullptr);

            tx = offset_out + tid_hor * stride_out[1] + (((thread + 0 + 0) / 8) * 64 + (thread + 0 + 0) % 8 + 24) * stride0_out;
            blue_data.transform_index = tx;
            bluestein_store_tmp(buf_out, tx, R[3], &blue_data, nullptr);

            tx = offset_out + tid_hor * stride_out[1] + (((thread + 0 + 0) / 8) * 64 + (thread + 0 + 0) % 8 + 32) * stride0_out;
            blue_data.transform_index = tx;
            bluestein_store_tmp(buf_out, tx, R[4], &blue_data, nullptr);

            tx = offset_out + tid_hor * stride_out[1] + (((thread + 0 + 0) / 8) * 64 + (thread + 0 + 0) % 8 + 40) * stride0_out;
            blue_data.transform_index = tx;
            bluestein_store_tmp(buf_out, tx, R[5], &blue_data, nullptr);

            tx = offset_out + tid_hor * stride_out[1] + (((thread + 0 + 0) / 8) * 64 + (thread + 0 + 0) % 8 + 48) * stride0_out;
            blue_data.transform_index = tx;
            bluestein_store_tmp(buf_out, tx, R[6], &blue_data, nullptr);

            tx = offset_out + tid_hor * stride_out[1] + (((thread + 0 + 0) / 8) * 64 + (thread + 0 + 0) % 8 + 56) * stride0_out;
            blue_data.transform_index = tx;
            bluestein_store_tmp(buf_out, tx, R[7], &blue_data, nullptr);
        }

        else
        {
            // can't use intrinsic store
            if (in_bound)
            {
                store_cb(buf_out,
                         offset_out + tid_hor * stride_out[1] + (((thread + 0 + 0) / 8) * 64 + (thread + 0 + 0) % 8 + 0) * stride0_out,
                         R[0],
                         store_cb_data,
                         nullptr);
                store_cb(buf_out,
                         offset_out + tid_hor * stride_out[1] + (((thread + 0 + 0) / 8) * 64 + (thread + 0 + 0) % 8 + 8) * stride0_out,
                         R[1],
                         store_cb_data,
                         nullptr);
                store_cb(buf_out,
                         offset_out + tid_hor * stride_out[1] + (((thread + 0 + 0) / 8) * 64 + (thread + 0 + 0) % 8 + 16) * stride0_out,
                         R[2],
                         store_cb_data,
                         nullptr);
                store_cb(buf_out,
                         offset_out + tid_hor * stride_out[1] + (((thread + 0 + 0) / 8) * 64 + (thread + 0 + 0) % 8 + 24) * stride0_out,
                         R[3],
                         store_cb_data,
                         nullptr);
                store_cb(buf_out,
                         offset_out + tid_hor * stride_out[1] + (((thread + 0 + 0) / 8) * 64 + (thread + 0 + 0) % 8 + 32) * stride0_out,
                         R[4],
                         store_cb_data,
                         nullptr);
                store_cb(buf_out,
                         offset_out + tid_hor * stride_out[1] + (((thread + 0 + 0) / 8) * 64 + (thread + 0 + 0) % 8 + 40) * stride0_out,
                         R[5],
                         store_cb_data,
                         nullptr);
                store_cb(buf_out,
                         offset_out + tid_hor * stride_out[1] + (((thread + 0 + 0) / 8) * 64 + (thread + 0 + 0) % 8 + 48) * stride0_out,
                         R[6],
                         store_cb_data,
                         nullptr);
                store_cb(buf_out,
                         offset_out + tid_hor * stride_out[1] + (((thread + 0 + 0) / 8) * 64 + (thread + 0 + 0) % 8 + 56) * stride0_out,
                         R[7],
                         store_cb_data,
                         nullptr);
            }

            if (!in_bound)
            {
                if (tile_index * 32 + tid_hor < lengths[1])
                {
                    store_cb(buf_out,
                             offset_out + tid_hor * stride_out[1] + (((thread + 0 + 0) / 8) * 64 + (thread + 0 + 0) % 8 + 0) * stride0_out,
                             R[0],
                             store_cb_data,
                             nullptr);
                    store_cb(buf_out,
                             offset_out + tid_hor * stride_out[1] + (((thread + 0 + 0) / 8) * 64 + (thread + 0 + 0) % 8 + 8) * stride0_out,
                             R[1],
                             store_cb_data,
                             nullptr);
                    store_cb(buf_out,
                             offset_out + tid_hor * stride_out[1] + (((thread + 0 + 0) / 8) * 64 + (thread + 0 + 0) % 8 + 16) * stride0_out,
                             R[2],
                             store_cb_data,
                             nullptr);
                    store_cb(buf_out,
                             offset_out + tid_hor * stride_out[1] + (((thread + 0 + 0) / 8) * 64 + (thread + 0 + 0) % 8 + 24) * stride0_out,
                             R[3],
                             store_cb_data,
                             nullptr);
                    store_cb(buf_out,
                             offset_out + tid_hor * stride_out[1] + (((thread + 0 + 0) / 8) * 64 + (thread + 0 + 0) % 8 + 32) * stride0_out,
                             R[4],
                             store_cb_data,
                             nullptr);
                    store_cb(buf_out,
                             offset_out + tid_hor * stride_out[1] + (((thread + 0 + 0) / 8) * 64 + (thread + 0 + 0) % 8 + 40) * stride0_out,
                             R[5],
                             store_cb_data,
                             nullptr);
                    store_cb(buf_out,
                             offset_out + tid_hor * stride_out[1] + (((thread + 0 + 0) / 8) * 64 + (thread + 0 + 0) % 8 + 48) * stride0_out,
                             R[6],
                             store_cb_data,
                             nullptr);
                    store_cb(buf_out,
                             offset_out + tid_hor * stride_out[1] + (((thread + 0 + 0) / 8) * 64 + (thread + 0 + 0) % 8 + 56) * stride0_out,
                             R[7],
                             store_cb_data,
                             nullptr);
                }
            }
        }
    }

    else
    {

        // store global
        __syncthreads();
        // no intrinsic when store from lds. FIXME- check why use nested branch is better
        if (in_bound)
        {
            store_cb(buf_out,
                     offset_out + (tid_hor * stride_out[1] + (thread + 0) * stride0_out),
                     lds_complex[tid_hor * stride_lds + (thread + 0) * 1],
                     store_cb_data,
                     nullptr);
            store_cb(buf_out,
                     offset_out + (tid_hor * stride_out[1] + (thread + 8) * stride0_out),
                     lds_complex[tid_hor * stride_lds + (thread + 8) * 1],
                     store_cb_data,
                     nullptr);
            store_cb(buf_out,
                     offset_out + (tid_hor * stride_out[1] + (thread + 16) * stride0_out),
                     lds_complex[tid_hor * stride_lds + (thread + 16) * 1],
                     store_cb_data,
                     nullptr);
            store_cb(buf_out,
                     offset_out + (tid_hor * stride_out[1] + (thread + 24) * stride0_out),
                     lds_complex[tid_hor * stride_lds + (thread + 24) * 1],
                     store_cb_data,
                     nullptr);
            store_cb(buf_out,
                     offset_out + (tid_hor * stride_out[1] + (thread + 32) * stride0_out),
                     lds_complex[tid_hor * stride_lds + (thread + 32) * 1],
                     store_cb_data,
                     nullptr);
            store_cb(buf_out,
                     offset_out + (tid_hor * stride_out[1] + (thread + 40) * stride0_out),
                     lds_complex[tid_hor * stride_lds + (thread + 40) * 1],
                     store_cb_data,
                     nullptr);
            store_cb(buf_out,
                     offset_out + (tid_hor * stride_out[1] + (thread + 48) * stride0_out),
                     lds_complex[tid_hor * stride_lds + (thread + 48) * 1],
                     store_cb_data,
                     nullptr);
            store_cb(buf_out,
                     offset_out + (tid_hor * stride_out[1] + (thread + 56) * stride0_out),
                     lds_complex[tid_hor * stride_lds + (thread + 56) * 1],
                     store_cb_data,
                     nullptr);
        }

        if (!in_bound)
        {
            if (tile_index * 32 + tid_hor < lengths[1])
            {
                store_cb(buf_out,
                         offset_out + (tid_hor * stride_out[1] + (thread + 0) * stride0_out),
                         lds_complex[tid_hor * stride_lds + (thread + 0) * 1],
                         store_cb_data,
                         nullptr);
                store_cb(buf_out,
                         offset_out + (tid_hor * stride_out[1] + (thread + 8) * stride0_out),
                         lds_complex[tid_hor * stride_lds + (thread + 8) * 1],
                         store_cb_data,
                         nullptr);
                store_cb(buf_out,
                         offset_out + (tid_hor * stride_out[1] + (thread + 16) * stride0_out),
                         lds_complex[tid_hor * stride_lds + (thread + 16) * 1],
                         store_cb_data,
                         nullptr);
                store_cb(buf_out,
                         offset_out + (tid_hor * stride_out[1] + (thread + 24) * stride0_out),
                         lds_complex[tid_hor * stride_lds + (thread + 24) * 1],
                         store_cb_data,
                         nullptr);
                store_cb(buf_out,
                         offset_out + (tid_hor * stride_out[1] + (thread + 32) * stride0_out),
                         lds_complex[tid_hor * stride_lds + (thread + 32) * 1],
                         store_cb_data,
                         nullptr);
                store_cb(buf_out,
                         offset_out + (tid_hor * stride_out[1] + (thread + 40) * stride0_out),
                         lds_complex[tid_hor * stride_lds + (thread + 40) * 1],
                         store_cb_data,
                         nullptr);
                store_cb(buf_out,
                         offset_out + (tid_hor * stride_out[1] + (thread + 48) * stride0_out),
                         lds_complex[tid_hor * stride_lds + (thread + 48) * 1],
                         store_cb_data,
                         nullptr);
                store_cb(buf_out,
                         offset_out + (tid_hor * stride_out[1] + (thread + 56) * stride0_out),
                         lds_complex[tid_hor * stride_lds + (thread + 56) * 1],
                         store_cb_data,
                         nullptr);
            }
        }
    }
}

#endif