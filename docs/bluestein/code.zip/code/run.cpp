#include <iostream>
#include <complex.h>
#include <stdio.h>
#include <vector>
#include <numeric>
#include <iomanip>

#include "hip/hip_runtime.h"
#include "compute_twiddles.h"
#include "compute_chirp.h"
#include "launch_bluestein_8192.h"

template <typename T>
void ComputeInputBuffer(size_t N, gpubuf_t<T> &input)
{
    std::vector<T> input_host(N);

    auto i = 0;
    for (auto &elem : input_host)
    {
        elem.x = i;
        elem.y = i;

        i++;
    }

    auto input_size_bytes = input_host.size() * sizeof(T);

    auto ret1 = input.alloc(input_size_bytes);

    auto ret2 = hipMemcpy(input.data(),
                          input_host.data(),
                          input_size_bytes,
                          hipMemcpyHostToDevice);
}

template <typename T>
void DisplayBuffer(size_t size, const gpubuf_t<T> &buffer)
{
    std::vector<T> buffer_host(size);

    auto buffer_size_bytes = size * sizeof(T);

    auto ret = hipMemcpy(buffer_host.data(),
                         buffer.data(),
                         buffer_size_bytes,
                         hipMemcpyDeviceToHost);

    for (const auto &elem : buffer_host)
    {
        std::cout << std::fixed << std::setw(16) << std::setprecision(16) << std::setfill('0') << elem.x << " + " << std::fixed << std::setw(16) << std::setprecision(16) << std::setfill('0') << elem.y << "i"
                  << ";" << std::endl;
    }
}

void RunBluestein8192()
{
    size_t N = 3989;
    size_t M = 8192, M1 = 64, M2 = 128;
    size_t tempBufferSize = 2 * M;

    std::vector<size_t> radices_M1 = {8, 8};
    std::vector<size_t> radices_M2 = {8, 4, 4};

    UserCallbacks callbacks;

    gpubuf_t<double2> inBuf, outBuf, tempBuf, chirpBuf;

    gpubuf_t<double2> twiddles_M1, twiddles_large_M1;
    gpubuf_t<double2> twiddles_M2;
    size_t largeTwdBase = 8;

    std::vector<size_t> length_1 = {M1, M2}, length_2 = {M2, M1};
    std::vector<size_t> inStride_1 = {M2, 1}, inStride_2 = {1, M2};
    std::vector<size_t> outStride_1 = {M2, 1}, outStride_2 = {1, M1};
    size_t iDist = M, oDist = M;
    size_t lds_padding = 0;

    size_t batch = 1;    

    auto ret = outBuf.alloc(N * sizeof(double2));
    ret = chirpBuf.alloc(N * sizeof(double2));
    ret = tempBuf.alloc(tempBufferSize * sizeof(double2));

    ComputeTwiddles(M1, radices_M1, twiddles_M1);
    ComputeTwiddlesLarge(M, largeTwdBase, twiddles_large_M1);
    ComputeTwiddles(M2, radices_M2, twiddles_M2);
    ComputeChirp(N, chirpBuf);

    GridParam gridParam1, gridParam2;
    gpubuf_t<size_t> devKernArg1, devKernArg2;

    GetSBCCArgs(length_1, inStride_1, outStride_1, iDist, oDist, batch, gridParam1, devKernArg1);
    GetSBRCArgs(length_2, inStride_2, outStride_2, iDist, oDist, batch, gridParam2, devKernArg2);

    size_t ntrial = 30;
    std::vector<double> gpu_time(ntrial);

    hipEvent_t start, stop;
    ret = hipEventCreate(&start);
    ret = hipEventCreate(&stop);

    for (unsigned int itrial = 0; itrial < gpu_time.size(); ++itrial)
    {
        ComputeInputBuffer(N, inBuf);

        ret = hipEventRecord(start);

        LaunchBluestein(N,
                        length_1,
                        length_2,
                        twiddles_M1,
                        twiddles_large_M1,
                        twiddles_M2,
                        lds_padding,
                        gridParam1,
                        gridParam2,
                        devKernArg1,
                        devKernArg2,
                        batch,
                        callbacks,
                        inBuf,
                        outBuf,
                        chirpBuf,
                        tempBuf);

        ret = hipEventRecord(stop);
        ret = hipEventSynchronize(stop);

        float time;
        ret = hipEventElapsedTime(&time, start, stop);
        gpu_time[itrial] = time;
    }    

    //DisplayBuffer(N, outBuf);

    std::cout << "\nExecution gpu time:";
    for (const auto &i : gpu_time)
    {
        std::cout << " " << i;
    }
    std::cout << " ms" << std::endl;
}

int main(int argc, char **argv)
{
    RunBluestein8192();

    return 0;
}