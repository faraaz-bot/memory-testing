#ifndef COMPUTE_CHIRP_H
#define COMPUTE_CHIRP_H

#include "launch_common.h"

#include "rocfft/chirp.h"

template <typename T>
void ComputeChirp(size_t N, gpubuf_t<T> &chirp)
{
    auto blockSize = CHIRP_THREADS;
    auto numBlocks = DivRoundingUp<size_t>(N, blockSize);

    hipLaunchKernelGGL(GenerateChirpKernel<T>,
                       dim3(numBlocks),
                       dim3(blockSize),
                       0, // sharedMemBytes
                       0,
                       N,
                       static_cast<T *>(chirp.data()));

    auto ret = hipDeviceSynchronize();
}

#endif