// Copyright (C) 2023 Advanced Micro Devices, Inc. All rights reserved.
//
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
//
// The above copyright notice and this permission notice shall be included in
// all copies or substantial portions of the Software.
//
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT.  IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
// THE SOFTWARE.

#ifndef CHIRP_H
#define CHIRP_H

#include "common.h"

static const unsigned int CHIRP_THREADS = 32;
static constexpr double PI_ = 3.141592653589793238462643383279;

template <typename T>
__global__ void __launch_bounds__(CHIRP_THREADS *CHIRP_THREADS)
    GenerateChirpKernel(const size_t N,
                        T *output)
{
    auto i = threadIdx.x + blockIdx.x * blockDim.x;

    if (i < N)
    {
        double c = cos(PI_ * (i * i) / N);
        double s = sin(PI_ * (i * i) / N);

        output[i].x = c;
        output[i].y = s;
    }
}

#endif // CHIRP_H
