#ifndef LAUNCH_BLUESTEIN_8192_H
#define LAUNCH_BLUESTEIN_8192_H

#include "launch_common.h"

#include "bluestein_8192/bluestein_64_sbcc_chirp.h"
#include "bluestein_8192/bluestein_128_sbrc_chirp.h"

#include "bluestein_8192/bluestein_64_sbcc_chirp_in.h"
#include "bluestein_8192/bluestein_128_sbrc_chirp_in.h"

#include "bluestein_8192/bluestein_64_sbcc_mul_chirp.h"
#include "bluestein_8192/bluestein_128_sbrc_mul_chirp.h"

void GetSBCCArgs(const std::vector<size_t> &length,
                 const std::vector<size_t> &inStride,
                 const std::vector<size_t> &outStride,
                 const size_t &iDist,
                 const size_t &oDist,
                 const size_t &batch,
                 GridParam &gridParam,
                 gpubuf_t<size_t> &devKernArg)
{
    auto workgroup_size = 256;
    auto threads_per_transform = 8;
    auto transforms_per_block = workgroup_size / threads_per_transform;

    unsigned int lds_padding = 0;

    auto bwd = transforms_per_block;
    auto lds = length[0] * bwd;

    gridParam.b_x = ((length[1]) - 1) / bwd + 1;
    gridParam.b_x *= std::accumulate(length.begin() + 2, length.end(), batch, std::multiplies<size_t>());
    gridParam.wgs_x = workgroup_size;

    gridParam.lds_bytes = (lds + lds_padding * bwd) * 2 * sizeof(double);

    devKernArg = kargs_create(length, inStride, outStride, iDist, oDist);
}

void GetSBRCArgs(const std::vector<size_t> &length,
                 const std::vector<size_t> &inStride,
                 const std::vector<size_t> &outStride,
                 const size_t &iDist,
                 const size_t &oDist,
                 const size_t &batch,
                 GridParam &gridParam,
                 gpubuf_t<size_t> &devKernArg)
{
    auto workgroup_size = 128;
    auto threads_per_transform = 16;
    auto transforms_per_block = workgroup_size / threads_per_transform;

    unsigned int lds_padding = 0;

    auto bwd = transforms_per_block;
    auto lds = length[0] * bwd;

    gridParam.b_x = ((length[1]) - 1) / bwd + 1;
    gridParam.b_x *= std::accumulate(length.begin() + 2, length.end(), batch, std::multiplies<size_t>());
    gridParam.wgs_x = workgroup_size;

    gridParam.lds_bytes = (lds + lds_padding * bwd) * 2 * sizeof(double);

    devKernArg = kargs_create(length, inStride, outStride, iDist, oDist);
}

inline void LaunchChirpFFT64SBCC(const size_t &N,
                                 const std::vector<size_t> &length,
                                 const gpubuf_t<double2> &twiddles,
                                 const gpubuf_t<double2> &twiddles_large,
                                 const size_t &lds_padding,
                                 const size_t &batch,
                                 const GridParam &gridParam,
                                 const gpubuf_t<size_t> &devKernArg,
                                 const UserCallbacks &callbacks,
                                 gpubuf_t<double2> &inBuf,
                                 gpubuf_t<double2> &outBuf,
                                 const gpubuf_t<double2> &chirpBuf,
                                 gpubuf_t<double2> &tempBuf)
{
    hipLaunchKernelGGL(op_forward_length64_SBCC_chirp,
                       dim3(gridParam.b_x),
                       dim3(gridParam.wgs_x),
                       gridParam.lds_bytes,
                       0,
                       twiddles.data(),
                       twiddles_large.data(),
                       length.size(),
                       N,
                       kargs_lengths(devKernArg),
                       kargs_stride_in(devKernArg),
                       kargs_stride_out(devKernArg),
                       batch,
                       lds_padding,
                       callbacks.load_cb_fn,
                       callbacks.load_cb_data,
                       callbacks.load_cb_lds_bytes,
                       callbacks.store_cb_fn,
                       callbacks.store_cb_data,
                       inBuf.data(),
                       outBuf.data(),
                       chirpBuf.data(),
                       tempBuf.data());
}

inline void LaunchChirpFFT128SBRC(const size_t &N,
                                  const std::vector<size_t> &length,
                                  const gpubuf_t<double2> &twiddles,
                                  const size_t &lds_padding,
                                  const size_t &batch,
                                  const GridParam &gridParam,
                                  const gpubuf_t<size_t> &devKernArg,
                                  const UserCallbacks &callbacks,
                                  gpubuf_t<double2> &inBuf,
                                  gpubuf_t<double2> &outBuf,
                                  const gpubuf_t<double2> &chirpBuf,
                                  gpubuf_t<double2> &tempBuf)
{
    hipLaunchKernelGGL(op_forward_length128_SBRC_chirp,
                       dim3(gridParam.b_x),
                       dim3(gridParam.wgs_x),
                       gridParam.lds_bytes,
                       0,
                       twiddles.data(),
                       length.size(),
                       N,
                       kargs_lengths(devKernArg),
                       kargs_stride_in(devKernArg),
                       kargs_stride_out(devKernArg),
                       batch,
                       lds_padding,
                       callbacks.load_cb_fn,
                       callbacks.load_cb_data,
                       callbacks.load_cb_lds_bytes,
                       callbacks.store_cb_fn,
                       callbacks.store_cb_data,
                       inBuf.data(),
                       outBuf.data(),
                       chirpBuf.data(),
                       tempBuf.data());
}

inline void LaunchChirpInFFT64SBCC(const size_t &N,
                                   const std::vector<size_t> &length,
                                   const gpubuf_t<double2> &twiddles,
                                   const gpubuf_t<double2> &twiddles_large,
                                   const size_t &lds_padding,
                                   const size_t &batch,
                                   const GridParam &gridParam,
                                   const gpubuf_t<size_t> &devKernArg,
                                   const UserCallbacks &callbacks,
                                   gpubuf_t<double2> &inBuf,
                                   gpubuf_t<double2> &outBuf,
                                   const gpubuf_t<double2> &chirpBuf,
                                   gpubuf_t<double2> &tempBuf)
{
    hipLaunchKernelGGL(op_forward_length64_SBCC_chirp_in,
                       dim3(gridParam.b_x),
                       dim3(gridParam.wgs_x),
                       gridParam.lds_bytes,
                       0,
                       twiddles.data(),
                       twiddles_large.data(),
                       length.size(),
                       N,
                       kargs_lengths(devKernArg),
                       kargs_stride_in(devKernArg),
                       kargs_stride_out(devKernArg),
                       batch,
                       lds_padding,
                       callbacks.load_cb_fn,
                       callbacks.load_cb_data,
                       callbacks.load_cb_lds_bytes,
                       callbacks.store_cb_fn,
                       callbacks.store_cb_data,
                       inBuf.data(),
                       outBuf.data(),
                       chirpBuf.data(),
                       tempBuf.data());
}

inline void LaunchChirpInFFT128SBRC(const size_t &N,
                                    const std::vector<size_t> &length,
                                    const gpubuf_t<double2> &twiddles,
                                    const size_t &lds_padding,
                                    const size_t &batch,
                                    const GridParam &gridParam,
                                    const gpubuf_t<size_t> &devKernArg,
                                    const UserCallbacks &callbacks,
                                    gpubuf_t<double2> &inBuf,
                                    gpubuf_t<double2> &outBuf,
                                    const gpubuf_t<double2> &chirpBuf,
                                    gpubuf_t<double2> &tempBuf)
{
    hipLaunchKernelGGL(op_forward_length128_SBRC_chirp_in,
                       dim3(gridParam.b_x),
                       dim3(gridParam.wgs_x),
                       gridParam.lds_bytes,
                       0,
                       twiddles.data(),
                       length.size(),
                       N,
                       kargs_lengths(devKernArg),
                       kargs_stride_in(devKernArg),
                       kargs_stride_out(devKernArg),
                       batch,
                       lds_padding,
                       callbacks.load_cb_fn,
                       callbacks.load_cb_data,
                       callbacks.load_cb_lds_bytes,
                       callbacks.store_cb_fn,
                       callbacks.store_cb_data,
                       inBuf.data(),
                       outBuf.data(),
                       chirpBuf.data(),
                       tempBuf.data());
}

inline void LaunchMulChirpFFT64SBCC(const size_t &N,
                                    const std::vector<size_t> &length,
                                    const gpubuf_t<double2> &twiddles,
                                    const gpubuf_t<double2> &twiddles_large,
                                    const size_t &lds_padding,
                                    const size_t &batch,
                                    const GridParam &gridParam,
                                    const gpubuf_t<size_t> &devKernArg,
                                    const UserCallbacks &callbacks,
                                    gpubuf_t<double2> &inBuf,
                                    gpubuf_t<double2> &outBuf,
                                    const gpubuf_t<double2> &chirpBuf,
                                    gpubuf_t<double2> &tempBuf)
{
    hipLaunchKernelGGL(op_inverse_length64_SBCC_mul_chirp,
                       dim3(gridParam.b_x),
                       dim3(gridParam.wgs_x),
                       gridParam.lds_bytes,
                       0,
                       twiddles.data(),
                       twiddles_large.data(),
                       length.size(),
                       N,
                       kargs_lengths(devKernArg),
                       kargs_stride_in(devKernArg),
                       kargs_stride_out(devKernArg),
                       batch,
                       lds_padding,
                       callbacks.load_cb_fn,
                       callbacks.load_cb_data,
                       callbacks.load_cb_lds_bytes,
                       callbacks.store_cb_fn,
                       callbacks.store_cb_data,
                       inBuf.data(),
                       outBuf.data(),
                       chirpBuf.data(),
                       tempBuf.data());
}

inline void LaunchMulChirpFFT128SBRC(const size_t &N,
                                     const std::vector<size_t> &length,
                                     const gpubuf_t<double2> &twiddles,
                                     const size_t &lds_padding,
                                     const size_t &batch,
                                     const GridParam &gridParam,
                                     const gpubuf_t<size_t> &devKernArg,
                                     const UserCallbacks &callbacks,
                                     gpubuf_t<double2> &inBuf,
                                     gpubuf_t<double2> &outBuf,
                                     const gpubuf_t<double2> &chirpBuf,
                                     gpubuf_t<double2> &tempBuf)
{
    hipLaunchKernelGGL(op_inverse_length128_SBRC_mul_chirp,
                       dim3(gridParam.b_x),
                       dim3(gridParam.wgs_x),
                       gridParam.lds_bytes,
                       0,
                       twiddles.data(),
                       length.size(),
                       N,
                       kargs_lengths(devKernArg),
                       kargs_stride_in(devKernArg),
                       kargs_stride_out(devKernArg),
                       batch,
                       lds_padding,
                       callbacks.load_cb_fn,
                       callbacks.load_cb_data,
                       callbacks.load_cb_lds_bytes,
                       callbacks.store_cb_fn,
                       callbacks.store_cb_data,
                       inBuf.data(),
                       outBuf.data(),
                       chirpBuf.data(),
                       tempBuf.data());
}

inline void LaunchBluestein(const size_t &N,
                            const std::vector<size_t> &length_1,
                            const std::vector<size_t> &length_2,
                            const gpubuf_t<double2> &twiddles_1,
                            const gpubuf_t<double2> &twiddles_1_large,
                            const gpubuf_t<double2> &twiddles_2,
                            const size_t &lds_padding,
                            const GridParam &gridParam1,
                            const GridParam &gridParam2,
                            gpubuf_t<size_t> &devKernArg1,
                            gpubuf_t<size_t> &devKernArg2,
                            const size_t &batch,
                            const UserCallbacks &callbacks,
                            gpubuf_t<double2> &inBuf,
                            gpubuf_t<double2> &outBuf,
                            const gpubuf_t<double2> &chirpBuf,
                            gpubuf_t<double2> &tempBuf)
{
    LaunchChirpFFT64SBCC(N,
                         length_1,
                         twiddles_1,
                         twiddles_1_large,
                         lds_padding,
                         batch,
                         gridParam1,
                         devKernArg1,
                         callbacks,
                         inBuf,
                         outBuf,
                         chirpBuf,
                         tempBuf);
    LaunchChirpFFT128SBRC(N,
                          length_2,
                          twiddles_2,
                          lds_padding,
                          batch,
                          gridParam2,
                          devKernArg2,
                          callbacks,
                          inBuf,
                          outBuf,
                          chirpBuf,
                          tempBuf);
    LaunchChirpInFFT64SBCC(N,
                           length_1,
                           twiddles_1,
                           twiddles_1_large,
                           lds_padding,
                           batch,
                           gridParam1,
                           devKernArg1,
                           callbacks,
                           inBuf,
                           outBuf,
                           chirpBuf,
                           tempBuf);
    LaunchChirpInFFT128SBRC(N,
                            length_2,
                            twiddles_2,
                            lds_padding,
                            batch,
                            gridParam2,
                            devKernArg2,
                            callbacks,
                            inBuf,
                            outBuf,
                            chirpBuf,
                            tempBuf);
    LaunchMulChirpFFT64SBCC(N,
                            length_1,
                            twiddles_1,
                            twiddles_1_large,
                            lds_padding,
                            batch,
                            gridParam1,
                            devKernArg1,
                            callbacks,
                            inBuf,
                            outBuf,
                            chirpBuf,
                            tempBuf);
    LaunchMulChirpFFT128SBRC(N,
                             length_2,
                             twiddles_2,
                             lds_padding,
                             batch,
                             gridParam2,
                             devKernArg2,
                             callbacks,
                             inBuf,
                             outBuf,
                             chirpBuf,
                             tempBuf);
}

#endif